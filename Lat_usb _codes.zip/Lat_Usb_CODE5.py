import numpy as np
import matplotlib.pyplot as plt

# ============================================================
#  S1223 CAMBER LINE (mm → nondimensional)
# ============================================================
S1223_X_mm = np.array([
    1.55,4.95,10.28,17.55,26.94,38.55,52.23,67.89,85.45,104.82,
    125.91,148.63,172.86,198.46,225.41,253.7,283.47,314.88,347.77,
    381.93,417.21,453.4,490.25,527.44,564.65,601.58,637.98,673.6,
    708.23,741.66,773.69,804.12,832.77,859.47,884.06,906.41,926.39,
    943.89,958.84,971.11,980.75,988.25,994.17,998.38,1000.0
])
S1223_Z_mm = np.array([
    0,3.5696,7.476781,12.050116,16.95118,22.056175,27.362229,
    32.78345,38.275198,43.780912,49.230336,54.648855,60.016002,
    65.242311,70.013725,74.222015,77.76345,80.657368,82.983428,
    84.736941,85.936617,86.613781,86.708099,86.272034,85.340245,
    83.894924,81.877902,79.236546,76.085827,72.46741,68.367651,
    63.741005,58.787064,53.572074,48.045531,42.303678,36.530153,
    30.76926,24.905231,19.340423,13.969052,8.819452,4.337855,
    1.162286,0.0
])

S1223_x = S1223_X_mm / 1000.0
S1223_z = S1223_Z_mm / 1000.0


# ============================================================
#  VORTEX ELEMENT FUNCTIONS
# ============================================================
def get_2d_induced_velocity(target_point, vortex_point, gamma=1.0, Mach=0.0):
    x, z = target_point
    xv, zv = vortex_point

    if Mach >= 1.0:
        raise ValueError("Mach must be < 1 for PG correction.")

    beta = np.sqrt(max(0.0, 1 - Mach**2))

    dx = x - xv
    dz = z - zv
    r2 = dx*dx + (beta*dz)**2

    if r2 < 1e-12:
        return np.zeros(2)

    fac = gamma / (2*np.pi*r2)
    u = fac * (beta * dz)
    w = -fac * (beta * dx)

    return np.array([u, w])


def discretize_curve(x_points, z_points):
    vort = []
    cp = []
    norm = []
    tan = []

    for i in range(len(x_points)-1):
        p1 = np.array([x_points[i],   z_points[i]])
        p2 = np.array([x_points[i+1], z_points[i+1]])

        vec = p2 - p1
        L = np.linalg.norm(vec)
        if L == 0:
            t = np.array([1.0,0.0])
        else:
            t = vec / L

        n = np.array([-t[1], t[0]])

        vort.append(p1 + 0.25*vec)
        cp.append(p1 + 0.75*vec)

        tan.append(t)
        norm.append(n)

    return {
        "vortices": np.array(vort),
        "control_points": np.array(cp),
        "normals": np.array(norm),
        "tangents": np.array(tan)
    }


# ============================================================
#  RECTANGULAR JET + TURN
# ============================================================
def generate_rectangular_jet(jet_z, num_panels, delta_j_deg, downstream_len=0.5):
    # upstream horizontal segment
    N1 = int(0.6 * num_panels)
    N2 = num_panels - N1

    x1 = np.linspace(0, 1, N1+1)
    z1 = np.full_like(x1, jet_z)

    # turning region
    theta = np.radians(delta_j_deg)
    s = np.linspace(0, downstream_len, N2+1)
    x2 = 1 + s*np.cos(theta)
    z2 = jet_z + s*np.sin(theta)

    x = np.concatenate([x1[:-1], x2])
    z = np.concatenate([z1[:-1], z2])

    return discretize_curve(x, z)


def plot_camber_and_rectangular_jet(jet_z, delta_j_deg=-60, downstream_len=0.5,
                                    num_panels_w=100, num_panels_j=200):
    """
    Plots the S1223 camber line and the rectangular jet (with turning)
    on the same figure.
    """

    # --------- Build Wing (S1223 Camber) ---------
    xw = np.linspace(0, 1, num_panels_w + 1)
    zw = np.interp(xw, S1223_x, S1223_z)   # uses embedded S1223 arrays

    # --------- Build Jet Geometry ---------
    jet = generate_rectangular_jet(jet_z, num_panels_j, delta_j_deg, downstream_len)
    jv = jet["vortices"]

    # --------- Plotting ---------
    plt.figure(figsize=(8,4))

    # Camber line
    plt.plot(xw, zw, '-k', linewidth=2, label='S1223 Camber Line')

    # Jet path (vortex points)
    plt.plot(jv[:,0], jv[:,1], '-r', linewidth=2, label='Rectangular Jet Path')

    # Markers
    plt.scatter(jv[:,0], jv[:,1], s=12, c='red')
    plt.scatter(xw, zw, s=10, c='black')

    plt.title(f"S1223 Camber vs Rectangular Jet (jet_z = {jet_z}, δj={delta_j_deg}°)")
    plt.xlabel("x/c")
    plt.ylabel("z/c")
    plt.grid(True)
    plt.legend()
    plt.tight_layout()
    plt.show()


# ============================================================
#  BUILD AIC MATRICES
# ============================================================
def compute_matrices(wing, jet, Mach_o, Mach_j):
    wv = wing["vortices"]
    wcp = wing["control_points"]
    wn = wing["normals"]

    jv = jet["vortices"]
    jcp = jet["control_points"]
    jn = jet["normals"]
    jt = jet["tangents"]

    Nw = len(wv)
    Nj = len(jv)

    N_WW = np.zeros((Nw,Nw))
    N_WJ = np.zeros((Nw,Nj))

    N_JW_o = np.zeros((Nj,Nw))
    S_JW_o = np.zeros((Nj,Nw))
    N_JJ_o = np.zeros((Nj,Nj))
    S_JJ_o = np.zeros((Nj,Nj))

    N_JW_j = np.zeros((Nj,Nw))
    S_JW_j = np.zeros((Nj,Nw))
    N_JJ_j = np.zeros((Nj,Nj))
    S_JJ_j = np.zeros((Nj,Nj))

    # Wing control points
    for i in range(Nw):
        P = wcp[i]
        n = wn[i]

        for k in range(Nw):
            v = get_2d_induced_velocity(P, wv[k], 1.0, Mach_o)
            N_WW[i,k] = np.dot(v,n)

        for k in range(Nj):
            v = get_2d_induced_velocity(P, jv[k], 1.0, Mach_o)
            N_WJ[i,k] = np.dot(v,n)

    # Jet control points
    for i in range(Nj):
        P = jcp[i]
        n = jn[i]
        t = jt[i]

        # Outer flow
        for k in range(Nw):
            v = get_2d_induced_velocity(P, wv[k], 1.0, Mach_o)
            N_JW_o[i,k] = np.dot(v,n)
            S_JW_o[i,k] = np.dot(v,t)

        for k in range(Nj):
            v = get_2d_induced_velocity(P, jv[k], 1.0, Mach_o)
            N_JJ_o[i,k] = np.dot(v,n)
            S_JJ_o[i,k] = np.dot(v,t)

        # Jet flow
        for k in range(Nw):
            v = get_2d_induced_velocity(P, wv[k], 1.0, Mach_j)
            N_JW_j[i,k] = np.dot(v,n)
            S_JW_j[i,k] = np.dot(v,t)

        for k in range(Nj):
            v = get_2d_induced_velocity(P, jv[k], 1.0, Mach_j)
            N_JJ_j[i,k] = np.dot(v,n)
            S_JJ_j[i,k] = np.dot(v,t)

    return {
        "N_WW":N_WW,"N_WJ":N_WJ,

        "N_JW_o":N_JW_o,"S_JW_o":S_JW_o,"N_JJ_o":N_JJ_o,"S_JJ_o":S_JJ_o,
        "N_JW_j":N_JW_j,"S_JW_j":S_JW_j,"N_JJ_j":N_JJ_j,"S_JJ_j":S_JJ_j
    }


# ============================================================
#  SOLVE 3-VARIABLE SYSTEM
# ============================================================
def solve_system(mats, wing, jet, V_o, V_j, rho_o, rho_j, alpha_deg, cmu):
    alpha = np.radians(alpha_deg)

    wcp = wing["control_points"]
    wnorm = wing["normals"]
    jnorm = jet["normals"]
    jtan  = jet["tangents"]

    Nw = len(wcp)
    Nj = len(jnorm)

    mu = V_o / V_j
    mu_p = cmu * mu
    T = rho_o / rho_j
    Tmu2 = T * mu*mu

    V_inf = V_o*np.array([np.cos(alpha), np.sin(alpha)])

    # --- Wing-alone gamma_wo
    RHS_wo = np.zeros(Nw)
    for i in range(Nw):
        RHS_wo[i] = -np.dot(V_inf, wnorm[i])

    gamma_wo = np.linalg.solve(mats["N_WW"], RHS_wo)

    # --- Build full system
    dphi_wo_dn = mats["N_JW_o"] @ gamma_wo
    dphi_wj_dn = dphi_wo_dn.copy()

    RHS1 = np.zeros(Nj)
    for i in range(Nj):
        n = jnorm[i]
        e = jtan[i]
        Ve = np.dot(V_inf, e)
        Vn = np.dot(V_inf, n)
        if abs(Ve) < 1e-12:
            geom = 0
        else:
            geom = Vn*(1 - mu_p)/Ve
        RHS1[i] = -geom + dphi_wj_dn[i] - dphi_wo_dn[i]

    dphi_wo_ds = mats["S_JW_o"] @ gamma_wo
    dphi_wj_ds = dphi_wo_ds.copy()

    RHS2 = np.zeros(Nj)
    for i in range(Nj):
        RHS2[i] = -dphi_wj_ds[i] + Tmu2*dphi_wo_ds[i]

    RHS3 = np.zeros(Nw)

    A = np.zeros((2*Nj + Nw, Nw + 2*Nj))
    b = np.zeros(2*Nj + Nw)

    # Eq 24
    A[0:Nj, 0:Nw] = mats["N_JW_o"]
    A[0:Nj, Nw:Nw+Nj] = mats["N_JJ_o"]
    A[0:Nj, Nw+Nj:Nw+2*Nj] = -mats["N_JJ_j"]
    b[0:Nj] = RHS1

    # Eq 25
    A[Nj:2*Nj, 0:Nw] = -Tmu2*mats["S_JW_o"]
    A[Nj:2*Nj, Nw:Nw+Nj] = -Tmu2*mats["S_JJ_o"]
    A[Nj:2*Nj, Nw+Nj:Nw+2*Nj] = mats["S_JJ_j"]
    b[Nj:2*Nj] = RHS2

    # Eq 26
    A[2*Nj:2*Nj+Nw, 0:Nw] = mats["N_WW"]
    A[2*Nj:2*Nj+Nw, Nw:Nw+Nj] = mats["N_WJ"]
    b[2*Nj:2*Nj+Nw] = RHS3

    sol = np.linalg.solve(A, b)

    gamma_wa = sol[0:Nw]
    gamma_oj = sol[Nw:Nw+Nj]
    gamma_jj = sol[Nw+Nj:Nw+2*Nj]

    return gamma_wo, gamma_wa, gamma_oj, gamma_jj


# ============================================================
#  LIFT / DRAG
# ============================================================
def compute_lift_drag(wing, gamma_w, alpha_deg, V):
    alpha = np.radians(alpha_deg)
    tan = wing["tangents"]
    theta = np.arctan2(tan[:,1], tan[:,0])

    integrand_Cl = gamma_w*np.cos(alpha - theta)/V
    integral = np.sum(integrand_Cl)
    Cl = 2*np.cos(alpha)*integral

    integrand_Cd = gamma_w*np.sin(alpha - theta)/V
    integral_d = np.sum(integrand_Cd)
    Cd = 2*np.cos(alpha)*integral_d

    return Cl, Cd


# ============================================================
#  MAIN
# ============================================================
def main():

    # ------------- USER INPUTS -------------
    V_o = 20
    V_j = 63.7
    rho_o = 1.225
    rho_j = 1.225
    alpha_deg = 0
    cmu = 3.927
    delta_j = 60
    num_panels_w = 100
    num_panels_j = 200
    jet_z = 0.02
    downstream_len = 0.5

    Mach_o = V_o/334.0
    Mach_j = V_j/334.0

    # ------------- BUILD WING -------------
    xw = np.linspace(0,1,num_panels_w+1)
    zw = np.interp(xw, S1223_x, S1223_z)
    wing = discretize_curve(xw, zw)

    # ------------- BUILD JET -------------
    jet = generate_rectangular_jet(jet_z, num_panels_j, delta_j, downstream_len)

    # ------------- MATRICES -------------
    mats = compute_matrices(wing, jet, Mach_o, Mach_j)

    # ------------- SOLVE SYSTEM -------------
    gamma_wo, gamma_wa, gamma_oj, gamma_jj = solve_system(
        mats, wing, jet, V_o, V_j, rho_o, rho_j, alpha_deg, cmu
    )

    gamma_w = gamma_wo + gamma_wa
    # ------------- LIFT & DRAG -------------
    Cl, Cd = compute_lift_drag(wing, gamma_w, alpha_deg, V_o)
    LD = Cl/Cd if Cd != 0 else np.inf

    print("\n================= FINAL RESULTS =================")
    print(f"Cl = {Cl:.6f}")
    print(f"Cd = {Cd:.6f}")
    print(f"L/D = {LD:.6f}")
    print("================================================\n")

    # ====================================================
    #  CL vs JET HEIGHT SWEEP
    # ====================================================
    heights = np.arange(0.16, 0.201, 0.01)
    Cl_sweep = []

    for h in heights:
        jet_h = generate_rectangular_jet(h, num_panels_j, delta_j, downstream_len)
        mats_h = compute_matrices(wing, jet_h, Mach_o, Mach_j)
        gamma_wo_h, gamma_wa_h, *_ = solve_system(mats_h, wing, jet_h, V_o, V_j, rho_o, rho_j, alpha_deg, cmu)
        gamma_w_h = gamma_wo_h + gamma_wa_h
        Cl_h, _ = compute_lift_drag(wing, gamma_w_h, alpha_deg, V_o)
        Cl_sweep.append(Cl_h)

    print("Jet Height Sweep (z_j vs Cl):")
    for z, c in zip(heights, Cl_sweep):
        print(f"z_j = {z:.2f} m   Cl = {c:.6f}")

    # ------------- PLOT SWEEP -------------
    plt.figure(figsize=(7,4))
    plt.plot(heights, Cl_sweep, '-o')
    plt.grid(True)
    plt.xlabel("Jet Height z_j (m)")
    plt.ylabel("Cl")
    plt.title("Cl vs Jet Height")
    plt.show()

    # ------------- PLOT GEOMETRY -------------
    plt.figure(figsize=(7,3))
    plt.plot(xw, zw, '-k', label="S1223 camber")
    jv = jet["vortices"]
    plt.plot(jv[:,0], jv[:,1], '-r', label="Jet path")
    plt.legend()
    plt.grid(True)
    plt.xlabel("x")
    plt.ylabel("z")
    plt.title("Geometry")
    plt.show()


# ============================================================
#  RUN
# ============================================================
if __name__ == "__main__":
    main()
plot_camber_and_rectangular_jet(jet_z=0.09, delta_j_deg=-60)
