import numpy as np
import matplotlib.pyplot as plt
import argparse

# ==========================================
# 1. GEOMETRY GENERATION
# ==========================================

def load_s1223_coords():
    """
    Returns the S1223 coordinates provided by the user.
    """
    data = """1.00000 0.00000
    0.99838 0.00126
    0.99417 0.00494
    0.98825 0.01037
    0.98075 0.01646
    0.97111 0.02250
    0.95884 0.02853
    0.94389 0.03476
    0.92639 0.04116
    0.90641 0.04768
    0.88406 0.05427
    0.85947 0.06089
    0.83277 0.06749
    0.80412 0.07402
    0.77369 0.08044
    0.74166 0.08671
    0.70823 0.09277
    0.67360 0.09859
    0.63798 0.10412
    0.60158 0.10935
    0.56465 0.11425
    0.52744 0.11881
    0.49025 0.12303
    0.45340 0.12683
    0.41721 0.13011
    0.38193 0.13271
    0.34777 0.13447
    0.31488 0.13526
    0.28347 0.13505
    0.25370 0.13346
    0.22541 0.13037
    0.19846 0.12594
    0.17286 0.12026
    0.14863 0.11355
    0.12591 0.10598
    0.10482 0.09770
    0.08545 0.08879
    0.06789 0.07940
    0.05223 0.06965
    0.03855 0.05968
    0.02694 0.04966
    0.01755 0.03961
    0.01028 0.02954
    0.00495 0.01969
    0.00155 0.01033
    0.00005 0.00178
    0.00044 -0.00561
    0.00264 -0.01120
    0.00789 -0.01427
    0.01718 -0.01550
    0.03006 -0.01584
    0.04627 -0.01532
    0.06561 -0.01404
    0.08787 -0.01202
    0.11282 -0.00925
    0.14020 -0.00563
    0.17006 -0.00075
    0.20278 0.00535
    0.23840 0.01213
    0.27673 0.01928
    0.31750 0.02652
    0.36044 0.03358
    0.40519 0.04021
    0.45139 0.04618
    0.49860 0.05129
    0.54639 0.05534
    0.59428 0.05820
    0.64176 0.05976
    0.68832 0.05994
    0.73344 0.05872
    0.77660 0.05612
    0.81729 0.05219
    0.85500 0.04706
    0.88928 0.04088
    0.91966 0.03387
    0.94573 0.02624
    0.96693 0.01822
    0.98255 0.01060
    0.99268 0.00468
    0.99825 0.00115
    1.00000 0.00000"""
    
    coords = []
    for line in data.split('\n'):
        if line.strip():
            coords.append([float(x) for x in line.split()])
    return np.array(coords)

def rotate_coords(points, angle_deg, center=(0,0)):
    """
    Rotates points around a center by angle_deg.
    """
    rad = np.radians(-angle_deg) # Negative for "Nose Up" in standard plotting
    c, s = np.cos(rad), np.sin(rad)
    ox, oy = center
    
    px = points[:, 0] - ox
    py = points[:, 1] - oy
    
    qx = ox + c * px - s * py
    qy = oy + s * px + c * py
    
    return np.column_stack((qx, qy))

def discretize_geometry(points):
    """
    Converts points into panels.
    """
    panels = []
    for i in range(len(points) - 1):
        p1 = points[i]
        p2 = points[i+1]
        
        vec = p2 - p1
        length = np.linalg.norm(vec)
        
        if length < 1e-9: continue
            
        tangent = vec / length
        normal = np.array([-tangent[1], tangent[0]]) # 90 deg CCW
        midpoint = p1 + 0.5 * vec
        
        panels.append({
            'p1': p1, 'p2': p2,
            'center': midpoint,
            'normal': normal,
            'tangent': tangent,
            'length': length
        })
    return panels

def build_geometries(chord_mm, case_id, alpha_deg, nozzle_x_pct=18.764, downstream_dist_factor=2.0):
    """
    Builds the Airfoil and Jet Sheet geometries, rotated by AoA.
    """
    # 1. Process Airfoil
    raw_coords = load_s1223_coords()
    airfoil_points = raw_coords * chord_mm
    
    # 2. Define Jet Boundaries (Horizontal initially)
    x_nozzle = - (nozzle_x_pct / 100.0) * chord_mm
    x_end = chord_mm * downstream_dist_factor
    
    if case_id == 1:
        z_top = 86.0
        z_bot = -15.0
    else:
        z_top = 124.6705
        z_bot = 23.6075
        
    num_jet_panels = 80
    x_vals = np.linspace(x_nozzle, x_end, num_jet_panels + 1)
    
    top_points = np.column_stack((x_vals, np.full_like(x_vals, z_top)))
    bot_points = np.column_stack((x_vals, np.full_like(x_vals, z_bot)))
    
    # 3. Apply Angle of Attack Rotation to ALL components
    # We rotate around the Leading Edge (0,0) or Quarter Chord? 
    # Usually Leading Edge (0,0) for geometry setups.
    
    if abs(alpha_deg) > 1e-5:
        airfoil_points = rotate_coords(airfoil_points, alpha_deg, center=(0,0))
        top_points = rotate_coords(top_points, alpha_deg, center=(0,0))
        bot_points = rotate_coords(bot_points, alpha_deg, center=(0,0))
    
    # 4. Discretize
    airfoil_panels = discretize_geometry(airfoil_points)
    jet_top_panels = discretize_geometry(top_points)
    jet_bot_panels = discretize_geometry(bot_points)
    
    return airfoil_panels, jet_top_panels, jet_bot_panels

# ==========================================
# 2. AERODYNAMICS SOLVER (4-SHEET)
# ==========================================

def get_induced_velocity(target, p1, p2, gamma, sigma):
    panel_vec = p2 - p1
    length = np.linalg.norm(panel_vec)
    tangent = panel_vec / length
    normal = np.array([-tangent[1], tangent[0]])
    
    d_vec = target - p1
    x_local = np.dot(d_vec, tangent)
    y_local = np.dot(d_vec, normal)
    
    r1_sq = x_local**2 + y_local**2
    r2_sq = (x_local - length)**2 + y_local**2
    
    theta1 = np.arctan2(y_local, x_local)
    theta2 = np.arctan2(y_local, x_local - length)
    
    if r1_sq < 1e-10 or r2_sq < 1e-10 or (y_local == 0 and 0 < x_local < length):
        return np.array([0.0, 0.5 * sigma]) 
        
    val_log = 0.5 * np.log(r2_sq / r1_sq)
    val_atan = theta2 - theta1
    
    u_src_loc = (sigma / (2*np.pi)) * val_log
    v_src_loc = (sigma / (2*np.pi)) * val_atan
    
    u_vtx_loc = (gamma / (2*np.pi)) * val_atan
    v_vtx_loc = -(gamma / (2*np.pi)) * val_log
    
    u_loc = u_src_loc + u_vtx_loc
    v_loc = v_src_loc + v_vtx_loc
    
    u_global = u_loc * tangent[0] - v_loc * tangent[1]
    v_global = u_loc * tangent[1] + v_loc * tangent[0]
    
    return np.array([u_global, v_global])

def build_influence_matrices(airfoil_panels, jet_top, jet_bot, Vo, Vj, rho_o, rho_j):
    Na = len(airfoil_panels)
    Nj = len(jet_top)
    
    N_total = Na + 4 * Nj 
    
    A = np.zeros((N_total, N_total))
    b = np.zeros(N_total)
    
    idx_ga = 0
    idx_gjt = Na
    idx_sjt = Na + Nj
    idx_gjb = Na + 2*Nj
    idx_sjb = Na + 3*Nj
    
    mu = Vo / Vj
    K_p = (rho_o * Vo) / (rho_j * Vj)
    
    # Since we rotated the geometry, the flow V_j and V_o come from the "left" (x-axis)
    # relative to the grid. 
    V_inf_vec = np.array([Vj, 0]) # Inside jet
    V_out_vec = np.array([Vo, 0]) # Outside
    
    # 1. AIRFOIL EQUATIONS (Neumann: V.n = 0)
    for i in range(Na):
        p_i = airfoil_panels[i]
        b[i] = -np.dot(V_inf_vec, p_i['normal'])
        
        for j in range(Na):
            vel = get_induced_velocity(p_i['center'], airfoil_panels[j]['p1'], airfoil_panels[j]['p2'], 1.0, 0.0)
            A[i, idx_ga + j] = np.dot(vel, p_i['normal'])
        for j in range(Nj):
            vel_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1.0, 0.0)
            A[i, idx_gjt + j] = np.dot(vel_g, p_i['normal'])
            vel_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0.0, 1.0)
            A[i, idx_sjt + j] = np.dot(vel_s, p_i['normal'])
        for j in range(Nj):
            vel_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1.0, 0.0)
            A[i, idx_gjb + j] = np.dot(vel_g, p_i['normal'])
            vel_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0.0, 1.0)
            A[i, idx_sjb + j] = np.dot(vel_s, p_i['normal'])

    # 2. JET BOUNDARY EQUATIONS
    sheets = [(jet_top, idx_gjt, idx_sjt), (jet_bot, idx_gjb, idx_sjb)]
    
    for sheet_idx, (panels, g_idx, s_idx) in enumerate(sheets):
        for i in range(Nj):
            p_i = panels[i]
            
            # EQ 3: Normal
            row_norm = Na + sheet_idx * (2*Nj) + i
            A[row_norm, s_idx + i] += 1.0 
            factor = (1.0 - mu)
            b[row_norm] = -factor * np.dot(V_inf_vec, p_i['normal'])
            
            for j in range(Na):
                vel = get_induced_velocity(p_i['center'], airfoil_panels[j]['p1'], airfoil_panels[j]['p2'], 1.0, 0.0)
                A[row_norm, idx_ga + j] += factor * np.dot(vel, p_i['normal'])
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1.0, 0.0)
                A[row_norm, idx_gjt + j] += factor * np.dot(vel_g, p_i['normal'])
                vel_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0.0, 1.0)
                A[row_norm, idx_sjt + j] += factor * np.dot(vel_s, p_i['normal'])
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1.0, 0.0)
                A[row_norm, idx_gjb + j] += factor * np.dot(vel_g, p_i['normal'])
                vel_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0.0, 1.0)
                A[row_norm, idx_sjb + j] += factor * np.dot(vel_s, p_i['normal'])
            
            # EQ 4: Tangential
            row_tan = Na + sheet_idx * (2*Nj) + Nj + i
            factor_tan = (1.0 - K_p)
            A[row_tan, g_idx + i] += 1.0
            b[row_tan] = -factor_tan * np.dot(V_inf_vec, p_i['tangent'])
            
            for j in range(Na):
                vel = get_induced_velocity(p_i['center'], airfoil_panels[j]['p1'], airfoil_panels[j]['p2'], 1.0, 0.0)
                A[row_tan, idx_ga + j] += factor_tan * np.dot(vel, p_i['tangent'])
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1.0, 0.0)
                A[row_tan, idx_gjt + j] += factor_tan * np.dot(vel_g, p_i['tangent'])
                vel_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0.0, 1.0)
                A[row_tan, idx_sjt + j] += factor_tan * np.dot(vel_s, p_i['tangent'])
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1.0, 0.0)
                A[row_tan, idx_gjb + j] += factor_tan * np.dot(vel_g, p_i['tangent'])
                vel_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0.0, 1.0)
                A[row_tan, idx_sjb + j] += factor_tan * np.dot(vel_s, p_i['tangent'])

    return A, b

def solve_and_postprocess(A, b, airfoil_panels, Vj, chord):
    x = np.linalg.solve(A, b)
    
    Na = len(airfoil_panels)
    gamma_airfoil = x[0:Na]
    
    gamma_sum = 0.0
    for i in range(Na):
        gamma_sum += gamma_airfoil[i] * airfoil_panels[i]['length']
    
    cl = 2.0 * gamma_sum / (Vj * chord)
    
    return cl

# ==========================================
# 3. MAIN
# ==========================================

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', type=int, default=1, help='1 for -15/86mm, 2 for 0/101mm')
    parser.add_argument('--V_jet', type=float, default=63.7)
    parser.add_argument('--V_out', type=float, default=20.0)
    # Added Alpha Argument
    parser.add_argument('--alpha', type=float, default=5.0, help='Angle of Attack (degrees)')
    args = parser.parse_args()
    
    chord = 175.0
    Vj = args.V_jet
    Vo = args.V_out
    rho = 0.905
    
    print(f"=== 4-VORTEX SHEET JET SIMULATION ===")
    print(f"Case: {args.case} | Alpha: {args.alpha}°")
    
    # 1. Build Geometry (Rotated)
    airfoil, jet_top, jet_bot = build_geometries(chord, case_id=2, 
                                                 alpha_deg=args.alpha, nozzle_x_pct=18.764)
    
    # 2. Build Matrices
    A, b = build_influence_matrices(airfoil, jet_top, jet_bot, Vo, Vj, rho, rho)
    
    # 3. Solve
    cl = solve_and_postprocess(A, b, airfoil, Vj, chord)
    
    print(f"\n=== RESULTS ===")
    print(f"Lift Coefficient (Cl): {cl:.4f}")
    
    # 4. Visualization
    plt.figure(figsize=(12, 6))
    
    p_af = np.array([p['p1'] for p in airfoil] + [airfoil[-1]['p2']])
    p_jt = np.array([p['p1'] for p in jet_top] + [jet_top[-1]['p2']])
    p_jb = np.array([p['p1'] for p in jet_bot] + [jet_bot[-1]['p2']])
    
    plt.plot(p_af[:,0], p_af[:,1], 'k-', linewidth=2, label='S1223 Airfoil')
    plt.plot(p_jt[:,0], p_jt[:,1], 'r--', linewidth=2, label='Jet Top')
    plt.plot(p_jb[:,0], p_jb[:,1], 'b--', linewidth=2, label='Jet Bottom')
    
    nx = p_jt[0,0]
    ny_top = p_jt[0,1]
    ny_bot = p_jb[0,1]
    
    # Draw rotated nozzle block approx
    plt.plot([nx, nx], [ny_bot, ny_top], 'k-', alpha=0.5)
    
    plt.title(f"Case {args.case} | Alpha={args.alpha}° | Cl={cl:.4f}")
    plt.xlabel("x (mm)")
    plt.ylabel("z (mm)")
    plt.axis('equal')
    plt.grid(True)
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()