import numpy as np
import matplotlib.pyplot as plt
import argparse
import io
import pandas as pd

# ==========================================
# 1. GEOMETRY GENERATION
# ==========================================

def load_s1223_coords():
    """
    Returns the S1223 coordinates provided by the user.
    """
    # Raw data provided by user
    data = """1.00000 0.00000
    0.99838 0.00126
    0.99417 0.00494
    0.98825 0.01037
    0.98075 0.01646
    0.97111 0.02250
    0.95884 0.02853
    0.94389 0.03476
    0.92639 0.04116
    0.90641 0.04768
    0.88406 0.05427
    0.85947 0.06089
    0.83277 0.06749
    0.80412 0.07402
    0.77369 0.08044
    0.74166 0.08671
    0.70823 0.09277
    0.67360 0.09859
    0.63798 0.10412
    0.60158 0.10935
    0.56465 0.11425
    0.52744 0.11881
    0.49025 0.12303
    0.45340 0.12683
    0.41721 0.13011
    0.38193 0.13271
    0.34777 0.13447
    0.31488 0.13526
    0.28347 0.13505
    0.25370 0.13346
    0.22541 0.13037
    0.19846 0.12594
    0.17286 0.12026
    0.14863 0.11355
    0.12591 0.10598
    0.10482 0.09770
    0.08545 0.08879
    0.06789 0.07940
    0.05223 0.06965
    0.03855 0.05968
    0.02694 0.04966
    0.01755 0.03961
    0.01028 0.02954
    0.00495 0.01969
    0.00155 0.01033
    0.00005 0.00178
    0.00044 -0.00561
    0.00264 -0.01120
    0.00789 -0.01427
    0.01718 -0.01550
    0.03006 -0.01584
    0.04627 -0.01532
    0.06561 -0.01404
    0.08787 -0.01202
    0.11282 -0.00925
    0.14020 -0.00563
    0.17006 -0.00075
    0.20278 0.00535
    0.23840 0.01213
    0.27673 0.01928
    0.31750 0.02652
    0.36044 0.03358
    0.40519 0.04021
    0.45139 0.04618
    0.49860 0.05129
    0.54639 0.05534
    0.59428 0.05820
    0.64176 0.05976
    0.68832 0.05994
    0.73344 0.05872
    0.77660 0.05612
    0.81729 0.05219
    0.85500 0.04706
    0.88928 0.04088
    0.91966 0.03387
    0.94573 0.02624
    0.96693 0.01822
    0.98255 0.01060
    0.99268 0.00468
    0.99825 0.00115
    1.00000 0.00000"""
    
    # Parse data
    coords = []
    for line in data.split('\n'):
        if line.strip():
            coords.append([float(x) for x in line.split()])
    return np.array(coords)

def discretize_geometry(points):
    """
    Converts points into panels (start, end, midpoint, normal, tangent, length).
    """
    panels = []
    for i in range(len(points) - 1):
        p1 = points[i]
        p2 = points[i+1]
        
        vec = p2 - p1
        length = np.linalg.norm(vec)
        
        if length < 1e-9: continue
            
        tangent = vec / length
        normal = np.array([-tangent[1], tangent[0]]) # 90 deg CCW
        midpoint = p1 + 0.5 * vec
        
        panels.append({
            'p1': p1, 'p2': p2,
            'center': midpoint,
            'normal': normal,
            'tangent': tangent,
            'length': length
        })
    return panels

def build_geometries(chord_mm, case_id, nozzle_x_pct=18.764, downstream_dist_factor=2.0):
    """
    Builds the Airfoil and Jet Sheet geometries.
    
    nozzle_x_pct: % chord UPSTREAM of LE where nozzle starts.
    case_id: 1 (Default) or 2 (Offset).
    """
    # 1. Process Airfoil
    raw_coords = load_s1223_coords()
    # Scale to chord (assuming raw is 0-1)
    airfoil_points = raw_coords * chord_mm
    airfoil_panels = discretize_geometry(airfoil_points)
    
    # 2. Define Jet Boundaries
    # Nozzle X location (Negative implies upstream)
    x_nozzle = - (nozzle_x_pct / 100.0) * chord_mm
    x_end = chord_mm * downstream_dist_factor
    
    # Vertical Positions relative to LE (z=0)
    if case_id == 1:
        # Case 1: Top @ 86mm, Bottom @ -15mm
        z_top = 86.0
        z_bot = -15.0
    else:
        # Case 2: Top @ 101mm, Bottom @ 0mm
        z_top = 101.0
        z_bot = 0.0
        
    # Generate Line Points
    num_jet_panels = 100 # Panels per sheet
    x_vals = np.linspace(x_nozzle, x_end, num_jet_panels + 1)
    
    # Top Sheet
    top_points = np.column_stack((x_vals, np.full_like(x_vals, z_top)))
    jet_top_panels = discretize_geometry(top_points)
    
    # Bottom Sheet
    bot_points = np.column_stack((x_vals, np.full_like(x_vals, z_bot)))
    jet_bot_panels = discretize_geometry(bot_points)
    
    return airfoil_panels, jet_top_panels, jet_bot_panels

# ==========================================
# 2. AERODYNAMICS SOLVER (4-SHEET)
# ==========================================

def get_induced_velocity(target, p1, p2, gamma, sigma):
    """
    Computes induced velocity (u, w) from a Constant Vortex + Constant Source panel.
    """
    # Panel Local Coordinate System
    panel_vec = p2 - p1
    length = np.linalg.norm(panel_vec)
    tangent = panel_vec / length
    normal = np.array([-tangent[1], tangent[0]])
    
    # Transform target to local coords (X along panel, Y normal)
    # Origin at p1
    d_vec = target - p1
    x_local = np.dot(d_vec, tangent)
    y_local = np.dot(d_vec, normal)
    
    # --- Analytical Formulas for Constant Source/Vortex ---
    # Radius to ends
    r1_sq = x_local**2 + y_local**2
    r2_sq = (x_local - length)**2 + y_local**2
    
    theta1 = np.arctan2(y_local, x_local)
    theta2 = np.arctan2(y_local, x_local - length)
    
    # Handle singularities (on the panel)
    if r1_sq < 1e-10 or r2_sq < 1e-10 or (y_local == 0 and 0 < x_local < length):
        # Self-influence
        # u_source = 0, v_source = 0.5 * sigma
        # u_vortex = 0, v_vortex = 0.5 * gamma (Cauchy principal value often 0, jump is gamma)
        # We handle matrix diagonal separately usually, but for field points:
        return np.array([0.0, 0.5 * sigma]) # Simple approx, refine in matrix
        
    # Standard Potential Functions
    # F = integral(1/r) -> ln(r) term
    # G = integral(theta) -> theta term
    
    val_log = 0.5 * np.log(r2_sq / r1_sq)
    val_atan = theta2 - theta1
    
    # Local velocities
    # Source (sigma): u = (sigma/2pi) * ln(r2/r1), v = (sigma/2pi) * (theta2-theta1)
    u_src_loc = (sigma / (2*np.pi)) * val_log
    v_src_loc = (sigma / (2*np.pi)) * val_atan
    
    # Vortex (gamma): u = (gamma/2pi) * (theta2-theta1), v = -(gamma/2pi) * ln(r2/r1)
    u_vtx_loc = (gamma / (2*np.pi)) * val_atan
    v_vtx_loc = -(gamma / (2*np.pi)) * val_log
    
    # Total Local
    u_loc = u_src_loc + u_vtx_loc
    v_loc = v_src_loc + v_vtx_loc
    
    # Rotate back to Global
    u_global = u_loc * tangent[0] - v_loc * tangent[1]
    v_global = u_loc * tangent[1] + v_loc * tangent[0]
    
    return np.array([u_global, v_global])

def build_influence_matrices(airfoil_panels, jet_top, jet_bot, Vo, Vj, rho_o, rho_j):
    """
    Constructs the linear system Ax = b.
    Unknowns Vector x order:
    [ Gamma_Airfoil_1 ... Gamma_Airfoil_Na, 
      Gamma_JetTop_1, Sigma_JetTop_1 ... 
      Gamma_JetBot_1, Sigma_JetBot_1 ... ]
    
    Actually, easier to group:
    x = [gamma_airfoil (Na), gamma_j_top (Nj), sigma_j_top (Nj), gamma_j_bot (Nj), sigma_j_bot (Nj)]
    """
    Na = len(airfoil_panels)
    Nj = len(jet_top) # Assume top and bot have same count
    
    N_total = Na + 4 * Nj # Airfoil(gamma) + Top(gamma,sigma) + Bot(gamma,sigma)
    
    A = np.zeros((N_total, N_total))
    b = np.zeros(N_total)
    
    # Indices map
    idx_ga = 0
    idx_gjt = Na
    idx_sjt = Na + Nj
    idx_gjb = Na + 2*Nj
    idx_sjb = Na + 3*Nj
    
    # Physics Constants
    mu = Vo / Vj
    # Eq 4 Factor: (rho_o * Vo) / (rho_j * Vj)
    # If using tangential velocity jump: u_j - u_o = gamma
    # Eq 4: rho_j*Vj*u_j = rho_o*Vo*u_o
    # Algebra: u_j = (rho_o*Vo)/(rho_j*Vj) * u_o
    # Let K = (rho_o*Vo)/(rho_j*Vj)
    # u_o + gamma = K * u_o  =>  gamma = (K-1)u_o
    # This relates gamma to u_o.
    K_p = (rho_o * Vo) / (rho_j * Vj)
    
    # ==========================
    # 1. AIRFOIL EQUATIONS (Neumann: V.n = 0)
    # ==========================
    for i in range(Na):
        p_i = airfoil_panels[i]
        
        # RHS: -V_inf . n (V_inf is Vj because airfoil is INSIDE jet)
        # Note: If Vj is dominant, we use Vj.
        b[i] = -np.dot(np.array([Vj, 0]), p_i['normal'])
        
        # Influence from Airfoil Gamma
        for j in range(Na):
            # Self-term logic for constant vortex panel: Normal velocity is zero? 
            # Actually for constant vortex, self V.n = 0.
            vel = get_induced_velocity(p_i['center'], airfoil_panels[j]['p1'], airfoil_panels[j]['p2'], 1.0, 0.0)
            A[i, idx_ga + j] = np.dot(vel, p_i['normal'])
            
        # Influence from Jet Top (Gamma + Sigma)
        for j in range(Nj):
            # Gamma contribution
            vel_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1.0, 0.0)
            A[i, idx_gjt + j] = np.dot(vel_g, p_i['normal'])
            # Sigma contribution
            vel_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0.0, 1.0)
            A[i, idx_sjt + j] = np.dot(vel_s, p_i['normal'])
            
        # Influence from Jet Bot (Gamma + Sigma)
        for j in range(Nj):
            # Gamma
            vel_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1.0, 0.0)
            A[i, idx_gjb + j] = np.dot(vel_g, p_i['normal'])
            # Sigma
            vel_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0.0, 1.0)
            A[i, idx_sjb + j] = np.dot(vel_s, p_i['normal'])

    # ==========================
    # 2. JET BOUNDARY EQUATIONS
    # ==========================
    # We loop over Top panels, then Bot panels
    # For each panel, we have 2 Eqs: (Eq 3: Normal) and (Eq 4: Tangential/Pressure)
    
    sheets = [(jet_top, idx_gjt, idx_sjt), (jet_bot, idx_gjb, idx_sjb)]
    
    for sheet_idx, (panels, g_idx, s_idx) in enumerate(sheets):
        for i in range(Nj):
            p_i = panels[i]
            
            # --- EQ 3: Linearized Flow Tangency ---
            # sigma = (mu - 1) * V_n_induced ? 
            # Or standard source sheet def: sigma = v_n_out - v_n_in
            # Eq 3 user provided: v_o_n(1-mu') + dphi_o/dn = mu' dphi_j/dn ...
            # Simplified for fixed geom: Source strength sigma models the divergence of streamlines.
            # sigma_i ~ (1 - Vo/Vj) * (Total_V_n)
            # Row index for this equation
            row_norm = Na + sheet_idx * (2*Nj) + i
            
            # This is complex to linearize perfectly without small perturbation assumption.
            # Let's use the standard "Transpiration BC" for jets:
            # Sigma_i + (1 - mu)*V_n_induced = (1-mu)*V_n_inf
            # V_n_induced is calculated using ALL singularities.
            
            # Coeff for Sigma_i self-term: 1.0
            # Plus influence of all others on V_n
            
            # 1. Self Sigma term (LHS)
            A[row_norm, s_idx + i] += 1.0 
            
            # 2. Influence of ALL panels on V_n at this jet panel
            # We add (1-mu) * (Influence . normal) to the matrix
            factor = (1.0 - mu)
            
            # RHS: (1 - mu) * (-V_inf . n). Note V_inf usually V_jet here as reference? 
            # Let's align with V_jet vector.
            # Actually, standard formula: sigma = (1 - (Vo/Vj)^2)? No, linear is (1 - Vo/Vj).
            b[row_norm] = -factor * np.dot(np.array([Vj, 0]), p_i['normal'])
            
            # Add influences to A matrix (similar to Airfoil loop but weighted by factor)
            # ... [Code block for influences on Jet Panel i normal velocity] ...
            # Airfoil Gamma
            for j in range(Na):
                vel = get_induced_velocity(p_i['center'], airfoil_panels[j]['p1'], airfoil_panels[j]['p2'], 1.0, 0.0)
                A[row_norm, idx_ga + j] += factor * np.dot(vel, p_i['normal'])
            
            # Jet Top (G+S)
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1.0, 0.0)
                A[row_norm, idx_gjt + j] += factor * np.dot(vel_g, p_i['normal'])
                # Self-influence of sigma on normal velocity is 0.5*sigma. 
                # But we already added +1.0 for the definition of sigma.
                # Usually Transpiration eq is: Sigma = ...
                # So we verify if self-term needs 0.5*factor. 
                # For flat panel, self induced normal velocity from constant source is 0.
                vel_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0.0, 1.0)
                A[row_norm, idx_sjt + j] += factor * np.dot(vel_s, p_i['normal'])

            # Jet Bot (G+S)
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1.0, 0.0)
                A[row_norm, idx_gjb + j] += factor * np.dot(vel_g, p_i['normal'])
                vel_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0.0, 1.0)
                A[row_norm, idx_sjb + j] += factor * np.dot(vel_s, p_i['normal'])
            
            
            # --- EQ 4: Pressure Continuity (Tangential) ---
            # gamma = (K_p - 1) * u_o
            # u_o is the velocity just outside the sheet.
            # u_o = V_o_inf_tangential + Induced_Tangential
            # Or better: u_avg = (u_in + u_out)/2. 
            # Linearized BC often uses: Gamma + (1 - K_p)*u_induced_tangential = ...
            
            row_tan = Na + sheet_idx * (2*Nj) + Nj + i # Offset by Nj within the sheet block
            
            # Formulation: Gamma_i + (1 - K_p) * (u_induced . tangent) = -(1 - K_p)*(V_j . tangent)
            # Note: We use Vj as the linearization velocity basis.
            
            factor_tan = (1.0 - K_p)
            
            # Self Gamma term
            A[row_tan, g_idx + i] += 1.0
            
            # RHS
            b[row_tan] = -factor_tan * np.dot(np.array([Vj, 0]), p_i['tangent'])
            
            # Influences (Tangential component)
            # Airfoil Gamma
            for j in range(Na):
                vel = get_induced_velocity(p_i['center'], airfoil_panels[j]['p1'], airfoil_panels[j]['p2'], 1.0, 0.0)
                A[row_tan, idx_ga + j] += factor_tan * np.dot(vel, p_i['tangent'])
            
            # Jet Top
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1.0, 0.0)
                A[row_tan, idx_gjt + j] += factor_tan * np.dot(vel_g, p_i['tangent'])
                vel_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0.0, 1.0)
                A[row_tan, idx_sjt + j] += factor_tan * np.dot(vel_s, p_i['tangent'])
                
            # Jet Bot
            for j in range(Nj):
                vel_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1.0, 0.0)
                A[row_tan, idx_gjb + j] += factor_tan * np.dot(vel_g, p_i['tangent'])
                vel_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0.0, 1.0)
                A[row_tan, idx_sjb + j] += factor_tan * np.dot(vel_s, p_i['tangent'])

    return A, b, idx_ga, idx_gjt, idx_sjt, idx_gjb, idx_sjb

def solve_and_postprocess(A, b, airfoil_panels, Vj, chord):
    """
    Solves the system and calculates CL.
    """
    x = np.linalg.solve(A, b)
    
    # Extract Airfoil Gamma (First Na elements)
    Na = len(airfoil_panels)
    gamma_airfoil = x[0:Na]
    
    # Calculate Lift
    # Kutta-Joukowski: L = rho * V * Gamma
    # CL = L / (0.5 * rho * V^2 * c) = 2 * Gamma / (V * c)
    # Total Circulation
    gamma_sum = 0.0
    for i in range(Na):
        # Gamma_panel is vorticity density? Or total strength?
        # My formulation used gamma as "strength factor".
        # For Constant Vortex Panel, 'gamma' usually denotes tangential velocity jump (vorticity/length).
        # So Total Circulation = sum(gamma_i * length_i)
        gamma_sum += gamma_airfoil[i] * airfoil_panels[i]['length']
    
    cl = 2.0 * gamma_sum / (Vj * chord)
    
    return cl, gamma_airfoil, x

# ==========================================
# 3. MAIN
# ==========================================

def main():
    # User Inputs
    # Case 1: Jet (-15mm to 86mm). Case 2: Jet (0mm to 101mm).
    # Nozzle X: -18.764% (Upstream)
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--case', type=int, default=1, help='1 for -15/86mm, 2 for 0/101mm')
    parser.add_argument('--V_jet', type=float, default=20, help='Jet Velocity (m/s)')
    parser.add_argument('--V_out', type=float, default=20.0, help='Outer Velocity (m/s)')
    args = parser.parse_args()
    
    chord = 175.0 # mm (Standard reference)
    Vj = args.V_jet
    Vo = args.V_out
    rho = 1.225
    
    print(f"=== 4-VORTEX SHEET JET SIMULATION ===")
    print(f"Case: {args.case}")
    print(f"Jet Velocity: {Vj} m/s | Outer Velocity: {Vo} m/s")
    
    # 1. Build Geometry
    airfoil, jet_top, jet_bot = build_geometries(chord, case_id=args.case, nozzle_x_pct=18.764)
    
    print(f"Geometry Built:")
    print(f"  Airfoil Panels: {len(airfoil)}")
    print(f"  Jet Top Panels: {len(jet_top)}")
    print(f"  Jet Bot Panels: {len(jet_bot)}")
    
    # 2. Build Matrices
    print("Building Interaction Matrices...")
    A, b, i_ga, i_gjt, i_sjt, i_gjb, i_sjb = build_influence_matrices(
        airfoil, jet_top, jet_bot, Vo, Vj, rho, rho
    )
    
    # 3. Solve
    print("Solving Linear System...")
    cl, gamma_foil, x_sol = solve_and_postprocess(A, b, airfoil, Vj, chord)
    
    print(f"\n=== RESULTS ===")
    print(f"Lift Coefficient (Cl): {cl:.4f}")
    
    # 4. Visualization
    plt.figure(figsize=(12, 6))
    
    # Plot Geometry
    p_af = np.array([p['p1'] for p in airfoil] + [airfoil[-1]['p2']])
    p_jt = np.array([p['p1'] for p in jet_top] + [jet_top[-1]['p2']])
    p_jb = np.array([p['p1'] for p in jet_bot] + [jet_bot[-1]['p2']])
    
    plt.plot(p_af[:,0], p_af[:,1], 'k-', linewidth=2, label='S1223 Airfoil')
    plt.plot(p_jt[:,0], p_jt[:,1], 'r--', linewidth=2, label='Jet Top')
    plt.plot(p_jb[:,0], p_jb[:,1], 'b--', linewidth=2, label='Jet Bottom')
    
    # Draw Nozzle Block (Schematic)
    nx = p_jt[0,0]
    plt.fill_between([nx-50, nx], [p_jb[0,1], p_jb[0,1]], [p_jt[0,1], p_jt[0,1]], color='gray', alpha=0.5, label='Nozzle')
    
    plt.title(f"S1223 in Co-Flow Jet (Case {args.case}) | Cl = {cl:.4f}")
    plt.xlabel("x (mm)")
    plt.ylabel("z (mm)")
    plt.axis('equal')
    plt.grid(True)
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()