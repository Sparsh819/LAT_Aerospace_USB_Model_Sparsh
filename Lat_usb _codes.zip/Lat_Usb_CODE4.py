import numpy as np

# --- 1. S1223 Camber Line Data (Extracted from your image) ---
# Coordinates are in mm, as provided in the table.
s1223_data = np.array([
    [0.27125, 1.80775],   [0.86625, 0.62468],   [1.799, 1.308437],
    [3.07125, 2.10877],   [4.7145, 2.966457],   [6.74625, 3.859831],
    [9.14025, 4.78839],   [11.88075, 5.737104], [14.95375, 6.69816],
    [18.3435, 7.66166],   [22.03425, 8.615309], [26.01025, 9.56355],
    [30.2505, 10.5028],   [34.7305, 11.4174],   [39.44675, 12.2524],
    [44.3975, 12.98885],  [49.60725, 13.6086],  [55.104, 14.11504],
    [60.85975, 14.5221],  [66.83775, 14.82897], [73.01175, 15.03891],
    [79.345, 15.15741],   [85.79375, 15.17392], [92.302, 15.09761],
    [98.81375, 14.93454], [105.2765, 14.68161], [111.6465, 14.32863],
    [117.88, 13.8664],    [123.9403, 13.31502], [129.7905, 12.6818],
    [135.3958, 11.96434], [140.721, 11.15468],  [145.7348, 10.28774],
    [150.4073, 9.375113], [154.7105, 8.407968], [158.6218, 7.403144],
    [162.1183, 6.392777], [165.1808, 5.38462],  [167.797, 4.358415],
    [169.9443, 3.384574], [171.6313, 2.444584], [172.9438, 1.543404],
    [173.9798, 0.759125], [174.7165, 0.2034],   [175.0, 0.0]
])

def get_s1223_camber(x_pts, chord_length=175.0):
    """
    Interpolates the S1223 camber line data.
    Input x_pts should be scaled 0 to 1.
    """
    # Scale data to unit chord (0 to 1) for calculation
    data_x = s1223_data[:, 0] / chord_length
    data_y = s1223_data[:, 1] / chord_length
    
    # Interpolate to find z (y-coordinate) for requested x
    return np.interp(x_pts, data_x, data_y)

# --- 2. Physics & Core Functions ---

def get_2d_induced_velocity(target_point, vortex_point, gamma=1.0):
    """
    Calculates induced velocity (u, w) from a point vortex.
    Simplified for Mach=0 (Incompressible).
    """
    x, z = target_point
    xv, zv = vortex_point
    
    dx = x - xv
    dz = z - zv
    r_sq = dx**2 + dz**2
    
    if r_sq < 1e-12:
        return np.zeros(2)

    factor = (gamma / (2 * np.pi * r_sq))
    
    u = factor * dz
    w = -factor * dx
    return np.array([u, w])

def discretize_curve(x_points, z_points):
    """
    Discretizes the curve into vortex panels.
    Vortex at 1/4 chord, Control Point at 3/4 chord.
    """
    num_panels = len(x_points) - 1
    vortices = []
    control_points = []
    normals = []
    
    for k in range(num_panels):
        p1 = np.array([x_points[k], z_points[k]])
        p2 = np.array([x_points[k+1], z_points[k+1]])
        
        # Panel Geometry
        panel_vec = p2 - p1
        length = np.linalg.norm(panel_vec)
        unit_tan = panel_vec / length
        
        # Normal (Standard: 90 deg counter-clockwise from tangent)
        unit_norm = np.array([-unit_tan[1], unit_tan[0]])
        
        # Vortex at 1/4, Control Point at 3/4
        vortex_loc = p1 + 0.25 * panel_vec
        cp_loc = p1 + 0.75 * panel_vec
        
        vortices.append(vortex_loc)
        control_points.append(cp_loc)
        normals.append(unit_norm)
        
    return {
        'vortices': np.array(vortices),
        'control_points': np.array(control_points),
        'normals': np.array(normals)
    }

def solve_wing_alone(wing_geom, flow_params):
    """
    Solves N_WW * gamma = RHS for a simple airfoil.
    """
    w_vort = wing_geom['vortices']
    w_cp   = wing_geom['control_points']
    w_norm = wing_geom['normals']
    Nw = len(w_vort)
    
    # 1. Build Influence Matrix N_WW
    N_WW = np.zeros((Nw, Nw))
    for i in range(Nw):
        target = w_cp[i]
        n_vec = w_norm[i]
        for k in range(Nw):
            vel = get_2d_induced_velocity(target, w_vort[k], gamma=1.0)
            N_WW[i, k] = np.dot(vel, n_vec)
            
    # 2. Build RHS (Boundary Condition: V . n = 0)
    Vo = flow_params['V_o']
    alpha_rad = np.radians(flow_params['alpha'])
    V_inf_vec = Vo * np.array([np.cos(alpha_rad), np.sin(alpha_rad)])
    
    RHS = np.zeros(Nw)
    for i in range(Nw):
        RHS[i] = -np.dot(V_inf_vec, w_norm[i])
        
    # 3. Solve for Gamma
    gamma = np.linalg.solve(N_WW, RHS)
    return gamma

# --- 3. Main Execution ---

if __name__ == "__main__":
    print("Initializing S1223 Analysis (No Jet)...")
    
    # Parameters
    params = {
        'V_o': 20.0,    # m/s
        'alpha': 0.0,   # degrees
        'chord': 1.0    # normalized chord
    }
    
    # Generate Geometry
    # We use 100 panels for resolution
    x_vals = np.linspace(0.0, 1.0, 100 + 1)
    z_vals = get_s1223_camber(x_vals, chord_length=175.0) 
    
    wing_geom = discretize_curve(x_vals, z_vals)
    
    # Solve
    gamma_distribution = solve_wing_alone(wing_geom, params)
    
    # Calculate Cl
    # Formula: Cl = 2 * Sum(Gamma) / (V_inf * Chord)
    total_circulation = np.sum(gamma_distribution)
    Cl = 2.0 * total_circulation / (params['V_o'] * params['chord'])
    
    print("-" * 30)
    print(f"Airfoil: S1223 (from data)")
    print(f"Flow: V={params['V_o']} m/s, Alpha={params['alpha']} deg")
    print("-" * 30)
    print(f"Calculated Cl: {Cl:.5f}")
    print("-" * 30)