#!/usr/bin/env python3
"""
usb_2d_s1223_4sheet_sweep.py

4-vortex-sheet rectangular jet model (S1223 camberline embedded).
Performs Cl vs gap sweep, prints values to terminal, and shows plots.

Defaults are modest (fast). Increase panel counts for more accuracy.
"""

import numpy as np
import argparse
import time
import matplotlib.pyplot as plt

# ------------------------
# S1223 camberline (embedded, mm)
# ------------------------
S1223_X_mm = np.array([
    1.55,4.95,10.28,17.55,26.94,38.55,52.23,67.89,85.45,104.82,
    125.91,148.63,172.86,198.46,225.41,253.7,283.47,314.88,347.77,
    381.93,417.21,453.4,490.25,527.44,564.65,601.58,637.98,673.6,
    708.23,741.66,773.69,804.12,832.77,859.47,884.06,906.41,926.39,
    943.89,958.84,971.11,980.75,988.25,994.17,998.38,1000.0
])
S1223_Z_mm = np.array([
    0,3.5696,7.476781,12.050116,16.95118,22.056175,27.362229,
    32.78345,38.275198,43.780912,49.230336,54.648855,60.016002,
    65.242311,70.013725,74.222015,77.76345,80.657368,82.983428,
    84.736941,85.936617,86.613781,86.708099,86.272034,85.340245,
    83.894924,81.877902,79.236546,76.085827,72.46741,68.367651,
    63.741005,58.787064,53.572074,48.045531,42.303678,36.530153,
    30.76926,24.905231,19.340423,13.969052,8.819452,4.337855,
    1.162286,0.0
])

# nondimensionalize to chord = 1.0 (1000 mm)
S1223_x = S1223_X_mm / 1000.0
S1223_z = S1223_Z_mm / 1000.0

# ------------------------
# Low-level vortex functions
# ------------------------
def get_2d_induced_velocity(target_point, vortex_point, gamma=1.0, Mach=0.0):
    x, z = target_point
    xv, zv = vortex_point
    if Mach >= 1.0:
        raise ValueError("Mach must be < 1 for PG correction.")
    beta = np.sqrt(max(0.0, 1 - Mach**2))
    dx = x - xv
    dz = z - zv
    r2 = dx*dx + (beta*dz)**2
    if r2 < 1e-12:
        return np.zeros(2)
    fac = gamma / (2.0 * np.pi * r2)
    u = fac * (beta * dz)
    w = -fac * (beta * dx)
    return np.array([u, w])

def discretize_curve(x_points, z_points):
    vortices = []
    cps = []
    normals = []
    tangents = []
    for k in range(len(x_points)-1):
        p1 = np.array([x_points[k], z_points[k]])
        p2 = np.array([x_points[k+1], z_points[k+1]])
        dv = p2 - p1
        L = np.linalg.norm(dv)
        t = dv / L if L > 0 else np.array([1.0, 0.0])
        n = np.array([-t[1], t[0]])
        vortices.append(p1 + 0.25*dv)
        cps.append(p1 + 0.75*dv)
        normals.append(n)
        tangents.append(t)
    return {
        'vortices': np.array(vortices),
        'control_points': np.array(cps),
        'normals': np.array(normals),
        'tangents': np.array(tangents)
    }

# ------------------------
# Rectangular jet surface generator
# ------------------------
def generate_rectangular_surface(jet_z, num_panels, delta_j_deg, downstream_len_chord):
    """
    Creates a single rectangular surface centerline:
    - horizontal from x=0..1 at z=jet_z (upstream)
    - then extends downstream_len_chord rotated by delta_j_deg about TE
    """
    n_pre = max(2, int(round(0.6 * num_panels)))
    n_post = max(1, num_panels - n_pre)
    x_pre = np.linspace(0.0, 1.0, n_pre + 1)
    z_pre = np.full_like(x_pre, jet_z)
    s = np.linspace(0.0, downstream_len_chord, n_post + 1)
    theta = np.deg2rad(delta_j_deg)
    x_post = 1.0 + s * np.cos(theta)
    z_post = jet_z + s * np.sin(theta)
    x_full = np.concatenate([x_pre[:-1], x_post])
    z_full = np.concatenate([z_pre[:-1], z_post])
    return discretize_curve(x_full, z_full)

# ------------------------
# Matrix builders and solver (Lan & Campbell style 3-var for each surface)
# ------------------------
def compute_usb_matrices(wing_geom, jet_geom, Mach_o=0.0, Mach_j=0.0):
    w_v = wing_geom['vortices']; w_cp = wing_geom['control_points']; w_n = wing_geom['normals']
    j_v = jet_geom['vortices']; j_cp = jet_geom['control_points']; j_n = jet_geom['normals']; j_t = jet_geom['tangents']
    Nw = len(w_v); Nj = len(j_v)
    N_WW = np.zeros((Nw, Nw)); N_WJ = np.zeros((Nw, Nj))
    N_JW_o = np.zeros((Nj, Nw)); S_JW_o = np.zeros((Nj, Nw)); N_JJ_o = np.zeros((Nj, Nj)); S_JJ_o = np.zeros((Nj, Nj))
    N_JW_j = np.zeros((Nj, Nw)); S_JW_j = np.zeros((Nj, Nw)); N_JJ_j = np.zeros((Nj, Nj)); S_JJ_j = np.zeros((Nj, Nj))
    # Wing controls
    for i in range(Nw):
        P = w_cp[i]; n = w_n[i]
        for k in range(Nw):
            v = get_2d_induced_velocity(P, w_v[k], gamma=1.0, Mach=Mach_o)
            N_WW[i, k] = np.dot(v, n)
        for k in range(Nj):
            v = get_2d_induced_velocity(P, j_v[k], gamma=1.0, Mach=Mach_o)
            N_WJ[i, k] = np.dot(v, n)
    # Jet controls
    for i in range(Nj):
        P = j_cp[i]; n = j_n[i]; t = j_t[i]
        for k in range(Nw):
            v = get_2d_induced_velocity(P, w_v[k], gamma=1.0, Mach=Mach_o)
            N_JW_o[i, k] = np.dot(v, n); S_JW_o[i, k] = np.dot(v, t)
        for k in range(Nj):
            v = get_2d_induced_velocity(P, j_v[k], gamma=1.0, Mach=Mach_o)
            N_JJ_o[i, k] = np.dot(v, n); S_JJ_o[i, k] = np.dot(v, t)
        for k in range(Nw):
            v = get_2d_induced_velocity(P, w_v[k], gamma=1.0, Mach=Mach_j)
            N_JW_j[i, k] = np.dot(v, n); S_JW_j[i, k] = np.dot(v, t)
        for k in range(Nj):
            v = get_2d_induced_velocity(P, j_v[k], gamma=1.0, Mach=Mach_j)
            N_JJ_j[i, k] = np.dot(v, n); S_JJ_j[i, k] = np.dot(v, t)
    return {
        "N_WW": N_WW, "N_WJ": N_WJ,
        "N_JW_o": N_JW_o, "S_JW_o": S_JW_o, "N_JJ_o": N_JJ_o, "S_JJ_o": S_JJ_o,
        "N_JW_j": N_JW_j, "S_JW_j": S_JW_j, "N_JJ_j": N_JJ_j, "S_JJ_j": S_JJ_j
    }

def solve_usb_3var_system(mats, wing_geom, jet_geom, flow_params):
    Vo = flow_params['V_o']; Vj = flow_params['V_j']; rho_o = flow_params['rho_o']; rho_j = flow_params['rho_j']; alpha_rad = np.radians(flow_params['alpha'])
    V_ent = flow_params.get('V_ent', np.array([0.0, 0.0]))
    Nw = mats['N_WW'].shape[0]; Nj = mats['N_JJ_o'].shape[0]
    mu = Vo / Vj; mu_dash = flow_params.get('cmu', 1.0) * mu
    T = rho_o / rho_j; T_mu2 = T * mu * mu
    w_norm = wing_geom['normals']; j_norm = jet_geom['normals']; j_tan = jet_geom['tangents']
    V_inf_vec = Vo * np.array([np.cos(alpha_rad), np.sin(alpha_rad)])
    # Wing-alone
    RHS_wo = np.zeros(Nw)
    for i in range(Nw):
        RHS_wo[i] = -np.dot(V_inf_vec, w_norm[i])
    gamma_wo = np.linalg.solve(mats['N_WW'], RHS_wo)
    # Build RHS1 (eq 24)
    dphi_wo_dn = mats['N_JW_o'] @ gamma_wo
    dphi_wj_dn = dphi_wo_dn.copy()
    RHS1 = np.zeros(Nj)
    for i in range(Nj):
        n_i = j_norm[i]; e_i = j_tan[i]
        Vo_dot_n = np.dot(V_inf_vec, n_i); Vo_dot_e = np.dot(V_inf_vec, e_i)
        geom_term = 0.0 if abs(Vo_dot_e) < 1e-12 else Vo_dot_n * (1.0 - mu_dash) / Vo_dot_e
        RHS1[i] = -geom_term + dphi_wj_dn[i] - dphi_wo_dn[i]
    # RHS2 (eq 25)
    dphi_wo_ds = mats['S_JW_o'] @ gamma_wo
    dphi_wj_ds = dphi_wo_ds.copy()
    RHS2 = np.zeros(Nj)
    for i in range(Nj):
        RHS2[i] = -dphi_wj_ds[i] + T_mu2 * dphi_wo_ds[i]
    # RHS3 (eq 26) entrainment vertical
    Vje_k = V_ent[1]
    RHS3 = np.full(Nw, -Vje_k / (Vo * np.cos(alpha_rad)))
    # Assemble and solve
    n_unknowns = Nw + 2 * Nj; n_eqs = 2 * Nj + Nw
    A = np.zeros((n_eqs, n_unknowns)); b = np.zeros(n_eqs)
    # eq 24
    A[0:Nj, 0:Nw] = mats['N_JW_o']
    A[0:Nj, Nw:Nw+Nj] = mats['N_JJ_o']
    A[0:Nj, Nw+Nj:Nw+2*Nj] = -mats['N_JJ_j']
    b[0:Nj] = RHS1
    # eq 25
    A[Nj:2*Nj, 0:Nw] = -T_mu2 * mats['S_JW_o']
    A[Nj:2*Nj, Nw:Nw+Nj] = -T_mu2 * mats['S_JJ_o']
    A[Nj:2*Nj, Nw+Nj:Nw+2*Nj] = mats['S_JJ_j']
    b[Nj:2*Nj] = RHS2
    # eq 26
    A[2*Nj:2*Nj+Nw, 0:Nw] = mats['N_WW']
    A[2*Nj:2*Nj+Nw, Nw:Nw+Nj] = mats['N_WJ']
    b[2*Nj:2*Nj+Nw] = RHS3
    sol = np.linalg.solve(A, b)
    gamma_wa = sol[0:Nw]; gamma_oj = sol[Nw:Nw+Nj]; gamma_jj = sol[Nw+Nj:Nw+2*Nj]
    return {"gamma_wo": gamma_wo, "gamma_wa": gamma_wa, "gamma_oj": gamma_oj, "gamma_jj": gamma_jj}

# ------------------------
# Lift/drag approx
# ------------------------
def compute_Cl_Cd(wing_geom, gamma_w, alpha_deg, V_o):
    alpha_rad = np.radians(alpha_deg)
    t = wing_geom['tangents']
    theta = np.arctan2(t[:,1], t[:,0])
    integrand_Cl = gamma_w * np.cos(alpha_rad - theta) / V_o
    integrand_Cd = gamma_w * np.sin(alpha_rad - theta) / V_o
    Cl = 2.0 * np.cos(alpha_rad) * np.sum(integrand_Cl)
    Cd = 2.0 * np.cos(alpha_rad) * np.sum(integrand_Cd)
    return Cl, Cd

# ------------------------
# Main runner
# ------------------------
def main():
    p = argparse.ArgumentParser()
    p.add_argument('--V_o', type=float, default=20.0)
    p.add_argument('--V_j', type=float, default=63.7)
    p.add_argument('--rho_o', type=float, default=1.225)
    p.add_argument('--rho_j', type=float, default=1.225)
    p.add_argument('--alpha', type=float, default=0.0)
    p.add_argument('--cmu', type=float, default=3.927)
    p.add_argument('--delta_j', type=float, default=-30.0)
    p.add_argument('--num_panels_w', type=int, default=80, help='wing panels (increase for accuracy)')
    p.add_argument('--num_panels_j', type=int, default=120, help='jet panels per surface')
    p.add_argument('--jet_thickness_mm', type=float, default=125.0)
    p.add_argument('--downstream_len_mm', type=float, default=700.0, help='horizontal jet length before turning (mm)')
    p.add_argument('--gap_max_mm', type=float, default=1.0, help='max gap to sweep (mm)')
    p.add_argument('--gap_step_mm', type=float, default=0.02, help='gap increment (mm)')
    args = p.parse_args()

    # physical params
    V_o = args.V_o; V_j = args.V_j; rho_o = args.rho_o; rho_j = args.rho_j; alpha_deg = args.alpha; cmu = args.cmu
    delta_j = args.delta_j
    num_panels_w = args.num_panels_w; num_panels_j = args.num_panels_j
    jet_thickness_m = args.jet_thickness_mm / 1000.0
    downstream_len_chord = args.downstream_len_mm / 1000.0
    Mach_o = V_o / 334.0; Mach_j = V_j / 334.0

    # build wing geometry
    xw = np.linspace(0.0, 1.0, num_panels_w + 1)
    zw = np.interp(xw, S1223_x, S1223_z)
    wing_geom = discretize_curve(xw, zw)

    # sweep gaps
    gap_mm = np.arange(0.0, args.gap_max_mm + 1e-9, args.gap_step_mm)
    gaps_m = gap_mm / 1000.0

    Cl_vals = []; Cd_vals = []; LD_vals = []
    t0 = time.time()
    for gap in gaps_m:
        # define horizontal surface z locations measured from camber TE upward + gap
        te_z = float(np.max(S1223_z))
        bottom_surface_z = te_z + gap
        top_surface_z = bottom_surface_z + jet_thickness_m

        # generate bottom & top surface geometries (each is a single vortex sheet centerline)
        bottom_geom = generate_rectangular_surface(bottom_surface_z, num_panels_j, delta_j, downstream_len_chord)
        top_geom = generate_rectangular_surface(top_surface_z, num_panels_j, delta_j, downstream_len_chord)

        flow_params = {'V_o': V_o, 'V_j': V_j, 'rho_o': rho_o, 'rho_j': rho_j,
                       'alpha': alpha_deg, 'V_ent': np.array([0.0, -2.0]), 'cmu': cmu}

        # compute matrices & solve for each surface (outer/inner for that surface)
        mats_bot = compute_usb_matrices(wing_geom, bottom_geom, Mach_o=Mach_o, Mach_j=Mach_j)
        sol_bot = solve_usb_3var_system(mats_bot, wing_geom, bottom_geom, flow_params)

        mats_top = compute_usb_matrices(wing_geom, top_geom, Mach_o=Mach_o, Mach_j=Mach_j)
        sol_top = solve_usb_3var_system(mats_top, wing_geom, top_geom, flow_params)

        # wing-alone (from bottom solve) and added contributions
        gamma_wo = sol_bot['gamma_wo']
        gamma_wa_total = sol_bot['gamma_wa'] + sol_top['gamma_wa']
        gamma_w_total = gamma_wo + gamma_wa_total

        Cl, Cd = compute_Cl_Cd(wing_geom, gamma_w_total, alpha_deg, V_o)
        LD = Cl/Cd if abs(Cd) > 1e-12 else np.inf

        Cl_vals.append(Cl); Cd_vals.append(Cd); LD_vals.append(LD)

    t1 = time.time()
    # print results
    print("\n=== RESULTS SUMMARY ===")
    print(f"Panels (wing, jet_per_surface): {num_panels_w}, {num_panels_j}")
    print(f"V_o = {V_o} m/s, V_j = {V_j} m/s, cmu = {cmu}, delta_j = {delta_j} deg")
    print(f"Sweep gaps 0 -> {args.gap_max_mm} mm step {args.gap_step_mm} mm  ({len(gap_mm)} points)")
    print(f"Completed in {t1-t0:.2f} s\n")

    print("Final results for gap = 0 mm:")
    print(f"Cl = {Cl_vals[0]:.6f}")
    print(f"Cd = {Cd_vals[0]:.6f}")
    print(f"L/D = {LD_vals[0]:.6f}\n")

    # print full table
    print("gap(mm)    Cl        Cd        L/D")
    for g, clv, cdv, ldv in zip(gap_mm, Cl_vals, Cd_vals, LD_vals):
        print(f"{g:6.2f}   {clv:9.6f}  {cdv:9.6f}  {ldv:9.6f}")

    # plots
    plt.figure(figsize=(8,4))
    plt.plot(gap_mm, Cl_vals, '-o', markersize=4)
    plt.xlabel("Gap above airfoil (mm)")
    plt.ylabel("Cl (approx)")
    plt.title("Cl vs Jet gap (approx, 4-sheet via superposition)")
    plt.grid(True)
    plt.show()

    # geometry figure for gap = 0
    rep_gap = 0.0
    te_z = float(np.max(S1223_z))
    bottom_z = te_z + rep_gap; top_z = bottom_z + jet_thickness_m
    g_bot = generate_rectangular_surface(bottom_z, num_panels_j, delta_j, downstream_len_chord)
    g_top = generate_rectangular_surface(top_z, num_panels_j, delta_j, downstream_len_chord)
    plt.figure(figsize=(9,3))
    x_plot = np.linspace(0, 1, 400)
    z_plot = np.interp(x_plot, S1223_x, S1223_z)
    plt.plot(x_plot, z_plot, '-k', label='S1223 camber')
    jb = g_bot['vortices']; jt = g_top['vortices']
    plt.plot(jb[:,0], jb[:,1], '-r', label='jet bottom surface')
    plt.plot(jt[:,0], jt[:,1], '-b', label='jet top surface')
    plt.legend(); plt.xlabel('x (c)'); plt.ylabel('z (c)'); plt.title('Camber + rectangular jet (gap=0 mm)'); plt.grid(True)
    plt.show()

if __name__ == "__main__":
    main()
