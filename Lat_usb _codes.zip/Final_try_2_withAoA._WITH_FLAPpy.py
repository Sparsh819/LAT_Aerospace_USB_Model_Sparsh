import numpy as np
import matplotlib.pyplot as plt
import argparse
from scipy.interpolate import interp1d

# ==========================================
# 1. GEOMETRY GENERATION
# ==========================================

def load_s1223_coords():
    """ Returns standard S1223 coordinates. """
    data = """1.00000 0.00000
    0.99838 0.00126
    0.99417 0.00494
    0.98825 0.01037
    0.98075 0.01646
    0.97111 0.02250
    0.95884 0.02853
    0.94389 0.03476
    0.92639 0.04116
    0.90641 0.04768
    0.88406 0.05427
    0.85947 0.06089
    0.83277 0.06749
    0.80412 0.07402
    0.77369 0.08044
    0.74166 0.08671
    0.70823 0.09277
    0.67360 0.09859
    0.63798 0.10412
    0.60158 0.10935
    0.56465 0.11425
    0.52744 0.11881
    0.49025 0.12303
    0.45340 0.12683
    0.41721 0.13011
    0.38193 0.13271
    0.34777 0.13447
    0.31488 0.13526
    0.28347 0.13505
    0.25370 0.13346
    0.22541 0.13037
    0.19846 0.12594
    0.17286 0.12026
    0.14863 0.11355
    0.12591 0.10598
    0.10482 0.09770
    0.08545 0.08879
    0.06789 0.07940
    0.05223 0.06965
    0.03855 0.05968
    0.02694 0.04966
    0.01755 0.03961
    0.01028 0.02954
    0.00495 0.01969
    0.00155 0.01033
    0.00005 0.00178
    0.00044 -0.00561
    0.00264 -0.01120
    0.00789 -0.01427
    0.01718 -0.01550
    0.03006 -0.01584
    0.04627 -0.01532
    0.06561 -0.01404
    0.08787 -0.01202
    0.11282 -0.00925
    0.14020 -0.00563
    0.17006 -0.00075
    0.20278 0.00535
    0.23840 0.01213
    0.27673 0.01928
    0.31750 0.02652
    0.36044 0.03358
    0.40519 0.04021
    0.45139 0.04618
    0.49860 0.05129
    0.54639 0.05534
    0.59428 0.05820
    0.64176 0.05976
    0.68832 0.05994
    0.73344 0.05872
    0.77660 0.05612
    0.81729 0.05219
    0.85500 0.04706
    0.88928 0.04088
    0.91966 0.03387
    0.94573 0.02624
    0.96693 0.01822
    0.98255 0.01060
    0.99268 0.00468
    0.99825 0.00115
    1.00000 0.00000"""
    coords = []
    for line in data.split('\n'):
        if line.strip():
            coords.append([float(x) for x in line.split()])
    return np.array(coords)

def rotate_points(points, angle_deg, center=(0,0)):
    """ Rotates points by angle_deg around center. """
    rad = np.radians(angle_deg)
    c, s = np.cos(rad), np.sin(rad)
    ox, oy = center
    
    px = points[:, 0] - ox
    py = points[:, 1] - oy
    
    qx = ox + c * px - s * py
    qy = oy + s * px + c * py
    
    return np.column_stack((qx, qy))

def discretize_geometry(points):
    """ Converts list of points into panel dicts. """
    panels = []
    for i in range(len(points) - 1):
        p1 = points[i]
        p2 = points[i+1]
        
        vec = p2 - p1
        length = np.linalg.norm(vec)
        if length < 1e-9: continue
            
        tangent = vec / length
        normal = np.array([-tangent[1], tangent[0]]) 
        midpoint = p1 + 0.5 * vec
        
        panels.append({
            'p1': p1, 'p2': p2,
            'center': midpoint,
            'normal': normal,
            'tangent': tangent,
            'length': length
        })
    return panels

def get_camber_line_y_at_x(x_loc, raw_coords):
    """
    Finds the y-coordinate of the camber line at a specific x_loc.
    Assumes raw_coords are sorted or structured standardly (LE to TE).
    """
    # Split into upper/lower
    min_x_idx = np.argmin(raw_coords[:, 0]) # usually LE
    # S1223 data typically wraps TE->Upper->LE->Lower->TE or similar
    # We'll just separate by y > 0 and y < 0 roughly for the camber approximation
    # Better: Split index
    
    # Sort by X for interpolation
    # Note: S1223 is highly cambered, so simple y>0 split is risky.
    # Using index split is safer for airfoil DAT files.
    upper = raw_coords[:min_x_idx+1]
    lower = raw_coords[min_x_idx:]
    
    # Ensure they are monotonic in X for interp
    # Flip upper if needed so X increases
    if upper[0,0] > upper[-1,0]: upper = upper[::-1]
    
    f_up = interp1d(upper[:,0], upper[:,1], bounds_error=False, fill_value="extrapolate")
    f_lo = interp1d(lower[:,0], lower[:,1], bounds_error=False, fill_value="extrapolate")
    
    y_u = f_up(x_loc)
    y_l = f_lo(x_loc)
    
    return (y_u + y_l) / 2.0

def generate_geometry(chord, alpha, delta_j, nozzle_x_pct=-18.764):
    """
    Generates the Airfoil and Jet geometries with the specified constraints:
    1. Jet Thickness = 101mm constant (initially).
    2. Jet starts at Nozzle X (-18.76%).
    3. At x = 122.5mm, both Airfoil (flap) and Jet bend by delta_j.
    """
    
    # --- 1. CONFIGURATION ---
    hinge_x = 122.5
    nozzle_x = (nozzle_x_pct / 100.0) * chord
    jet_end_x = 2.5 * chord 
    
    z_jet_top = 124.6705
    z_jet_bot = 23.6705

    
    # --- 2. AIRFOIL GENERATION ---
    raw = load_s1223_coords() * chord
    hinge_y = get_camber_line_y_at_x(hinge_x, raw)
    hinge_pt = np.array([hinge_x, hinge_y])
    
    airfoil_pts = []
    for p in raw:
        if p[0] > hinge_x:
            # Flap: Rotate around hinge
            p_rot = rotate_points(np.array([p]), delta_j, center=hinge_pt)[0]
            airfoil_pts.append(p_rot)
        else:
            # Main Wing: Fixed
            airfoil_pts.append(p)
    airfoil_pts = np.array(airfoil_pts)
    
    # --- 3. JET GENERATION ---
    # We define two segments: Upstream (Straight) and Downstream (Bent)
    
    # Upstream X points
    x_up = np.linspace(nozzle_x, hinge_x, 40)
    # Downstream X points (local coordinate before rotation)
    len_down = jet_end_x - hinge_x
    x_local_down = np.linspace(0, len_down, 50)
    
    # -- Jet Top --
    # Segment 1: Constant Z
    top_up = np.column_stack((x_up, np.full_like(x_up, z_jet_top)))
    
    # Segment 2: Start at hinge, rotate vector
    # Pivot for Top Sheet is (hinge_x, z_jet_top)
    pivot_top = np.array([hinge_x, z_jet_top])
    
    # Create points extending horizontally from pivot
    top_down_base = np.column_stack((x_local_down + hinge_x, np.full_like(x_local_down, z_jet_top)))
    # Rotate them around pivot
    top_down_rot = rotate_points(top_down_base, delta_j, center=pivot_top)
    
    jet_top_pts = np.vstack((top_up, top_down_rot[1:])) # [1:] to avoid duplicate point at hinge
    
    # -- Jet Bot --
    # Segment 1: Constant Z
    bot_up = np.column_stack((x_up, np.full_like(x_up, z_jet_bot)))
    
    # Segment 2: Pivot for Bot Sheet is (hinge_x, z_jet_bot)
    pivot_bot = np.array([hinge_x, z_jet_bot])
    
    bot_down_base = np.column_stack((x_local_down + hinge_x, np.full_like(x_local_down, z_jet_bot)))
    bot_down_rot = rotate_points(bot_down_base, delta_j, center=pivot_bot)
    
    jet_bot_pts = np.vstack((bot_up, bot_down_rot[1:]))
    
    # --- 4. GLOBAL ROTATION (ANGLE OF ATTACK) ---
    # Rotate EVERYTHING by -alpha around (0,0)
    rot_alpha = -alpha
    
    final_airfoil = rotate_points(airfoil_pts, rot_alpha, center=(0,0))
    final_jet_top = rotate_points(jet_top_pts, rot_alpha, center=(0,0))
    final_jet_bot = rotate_points(jet_bot_pts, rot_alpha, center=(0,0))
    
    return (discretize_geometry(final_airfoil), 
            discretize_geometry(final_jet_top), 
            discretize_geometry(final_jet_bot))

# ==========================================
# 3. SOLVER & POST-PROCESS
# ==========================================

def get_induced_velocity(target, p1, p2, gamma, sigma):
    # Standard source/vortex panel influence
    panel_vec = p2 - p1
    length = np.linalg.norm(panel_vec)
    tangent = panel_vec / length
    normal = np.array([-tangent[1], tangent[0]])
    
    d_vec = target - p1
    x_local = np.dot(d_vec, tangent)
    y_local = np.dot(d_vec, normal)
    
    r1_sq = x_local**2 + y_local**2
    r2_sq = (x_local - length)**2 + y_local**2
    
    theta1 = np.arctan2(y_local, x_local)
    theta2 = np.arctan2(y_local, x_local - length)
    
    if r1_sq < 1e-10 or r2_sq < 1e-10 or (y_local == 0 and 0 < x_local < length):
        return np.array([0.0, 0.5 * sigma])
        
    val_log = 0.5 * np.log(r2_sq / r1_sq)
    val_atan = theta2 - theta1
    
    u_src_loc = (sigma / (2*np.pi)) * val_log
    v_src_loc = (sigma / (2*np.pi)) * val_atan
    u_vtx_loc = (gamma / (2*np.pi)) * val_atan
    v_vtx_loc = -(gamma / (2*np.pi)) * val_log
    
    u_loc = u_src_loc + u_vtx_loc
    v_loc = v_src_loc + v_vtx_loc
    
    u_global = u_loc * tangent[0] - v_loc * tangent[1]
    v_global = u_loc * tangent[1] + v_loc * tangent[0]
    
    return np.array([u_global, v_global])

def solve_system(airfoil, jet_top, jet_bot, Vo, Vj, rho_o, rho_j):
    Na = len(airfoil)
    Nj = len(jet_top)
    N_total = Na + 4 * Nj 
    
    A = np.zeros((N_total, N_total))
    b = np.zeros(N_total)
    
    idx_ga = 0
    idx_gjt = Na
    idx_sjt = Na + Nj
    idx_gjb = Na + 2*Nj
    idx_sjb = Na + 3*Nj
    
    mu = Vo / Vj
    K_p = (rho_o * Vo) / (rho_j * Vj)
    V_inf_vec = np.array([Vj, 0]) # Flow is local to rotated jet
    
    # Airfoil Neumann
    for i in range(Na):
        p_i = airfoil[i]
        b[i] = -np.dot(V_inf_vec, p_i['normal'])
        for j in range(Na):
            A[i, idx_ga+j] = np.dot(get_induced_velocity(p_i['center'], airfoil[j]['p1'], airfoil[j]['p2'], 1, 0), p_i['normal'])
        for j in range(Nj):
            # Jet Top
            A[i, idx_gjt+j] = np.dot(get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1, 0), p_i['normal'])
            A[i, idx_sjt+j] = np.dot(get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0, 1), p_i['normal'])
            # Jet Bot
            A[i, idx_gjb+j] = np.dot(get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1, 0), p_i['normal'])
            A[i, idx_sjb+j] = np.dot(get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0, 1), p_i['normal'])

    # Jet Sheets
    sheets = [(jet_top, idx_gjt, idx_sjt), (jet_bot, idx_gjb, idx_sjb)]
    for sheet_idx, (panels, g_idx, s_idx) in enumerate(sheets):
        for i in range(Nj):
            p_i = panels[i]
            # Normal BC
            row_n = Na + sheet_idx * (2*Nj) + i
            A[row_n, s_idx + i] += 1.0
            factor = (1.0 - mu)
            b[row_n] = -factor * np.dot(V_inf_vec, p_i['normal'])
            
            # Influence loops (Airfoil, Jet Top, Jet Bot)
            for j in range(Na):
                A[row_n, idx_ga+j] += factor * np.dot(get_induced_velocity(p_i['center'], airfoil[j]['p1'], airfoil[j]['p2'], 1, 0), p_i['normal'])
            for j in range(Nj):
                v_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0, 1)
                A[row_n, idx_gjt+j] += factor * np.dot(v_g, p_i['normal'])
                A[row_n, idx_sjt+j] += factor * np.dot(v_s, p_i['normal'])
                
                v_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0, 1)
                A[row_n, idx_gjb+j] += factor * np.dot(v_g, p_i['normal'])
                A[row_n, idx_sjb+j] += factor * np.dot(v_s, p_i['normal'])

            # Tangential BC
            row_t = Na + sheet_idx * (2*Nj) + Nj + i
            factor_tan = (1.0 - K_p)
            A[row_t, g_idx + i] += 1.0
            b[row_t] = -factor_tan * np.dot(V_inf_vec, p_i['tangent'])
            
            for j in range(Na):
                A[row_t, idx_ga+j] += factor_tan * np.dot(get_induced_velocity(p_i['center'], airfoil[j]['p1'], airfoil[j]['p2'], 1, 0), p_i['tangent'])
            for j in range(Nj):
                v_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0, 1)
                A[row_t, idx_gjt+j] += factor_tan * np.dot(v_g, p_i['tangent'])
                A[row_t, idx_sjt+j] += factor_tan * np.dot(v_s, p_i['tangent'])
                
                v_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0, 1)
                A[row_t, idx_gjb+j] += factor_tan * np.dot(v_g, p_i['tangent'])
                A[row_t, idx_sjb+j] += factor_tan * np.dot(v_s, p_i['tangent'])

    x = np.linalg.solve(A, b)
    gamma_airfoil = x[0:Na]
    gamma_sum = sum(gamma_airfoil[i] * airfoil[i]['length'] for i in range(Na))
    return 2.0 * gamma_sum / (Vj * 175.0)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--alpha', type=float, default=0)
    parser.add_argument('--delta_j', type=float, default=0.0)
    parser.add_argument('--V_jet', type=float, default=63.7)
    parser.add_argument('--V_out', type=float, default=20)
    args = parser.parse_args()
    
    chord = 175.0
    
    print(f"=== JET SIMULATION (THICKNESS 101mm) ===")
    print(f"Angle of Attack: {args.alpha}°")
    print(f"Flap/Jet Deflection: {args.delta_j}°")
    print(f"Velocity Ratio: {args.V_jet/args.V_out:.2f}")

    # 1. Generate Geometry
    airfoil, jet_top, jet_bot = generate_geometry(chord, args.alpha, args.delta_j)
    
    # 2. Solve
    cl = solve_system(airfoil, jet_top, jet_bot, args.V_out, args.V_jet, 1.225, 1.225)
    print(f"Cl: {cl:.4f}")

    # 3. Plot
    plt.figure(figsize=(12, 6))
    
    p_af = np.array([p['p1'] for p in airfoil] + [airfoil[-1]['p2']])
    p_jt = np.array([p['p1'] for p in jet_top] + [jet_top[-1]['p2']])
    p_jb = np.array([p['p1'] for p in jet_bot] + [jet_bot[-1]['p2']])
    
    plt.plot(p_af[:,0], p_af[:,1], 'k-', label='S1223', linewidth=2)
    plt.plot(p_jt[:,0], p_jt[:,1], 'r--', label='Jet Top (101mm)')
    plt.plot(p_jb[:,0], p_jb[:,1], 'b--', label='Jet Bot (0mm)')
    
    # Indicate Hinge Line
    # Hinge is at x=122.5 rotated by alpha
    h_x = 122.5 * np.cos(np.radians(-args.alpha))
    h_y = 122.5 * np.sin(np.radians(-args.alpha))
    plt.axvline(x=h_x, color='g', linestyle=':', alpha=0.5, label='Hinge Line (Approx)')

    plt.title(f"USB Simulation | Alpha={args.alpha}° | Delta_j={args.delta_j}° | Cl={cl:.4f}")
    plt.axis('equal')
    plt.grid(True)
    plt.legend()
    plt.show()

if __name__ == "__main__":
    main()