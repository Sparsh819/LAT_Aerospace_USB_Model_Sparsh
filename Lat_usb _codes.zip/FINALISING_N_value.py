import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import UnivariateSpline

# --- 1. CONFIGURATION ---
alpha_deg = 5.0
alpha_rad = np.radians(alpha_deg)
M0 = 0.0587
delta_j_deg = 60.0  # Positive downward
C_mu = 0.607        # Jet momentum coefficient

# Jet Reaction Component (Constant)
CL_jet = C_mu * np.sin(np.radians(delta_j_deg + alpha_deg))

# --- 2. AIRFOIL DEFINITION (User Provided Coordinates) ---
def get_user_camber_slope(x_control_points):
    """
    Returns dz/dx using the specific coordinate table provided by the user.
    """
    # DATA TRANSCRIPTION FROM IMAGE (in mm)
    x_mm = np.array([
        0.0,       # Added anchor at LE
        0.27125, 0.86625, 1.799, 3.07125, 4.7145, 6.74625, 9.14025, 
        11.88075, 14.95375, 18.3435, 22.03425, 26.01025, 30.2505, 34.7305, 
        39.44675, 44.3975, 49.60725, 55.104, 60.85975, 66.83775, 73.01175, 
        79.345, 85.79375, 92.302, 98.81375, 105.2765, 111.6465, 117.88, 
        123.9403, 129.7905, 135.3958, 140.721, 145.7348, 150.4073, 154.7105, 
        158.6218, 162.1183, 165.1808, 167.797, 169.9443, 171.6313, 172.9438, 
        173.9798, 174.7165, 175.0
    ])

    y_mm = np.array([
        0.0,       # Added anchor at LE
        1.80775, 0.62468, 1.308437, 2.10877, 2.966457, 3.859831, 4.78839, 
        5.737104, 6.69816, 7.66166, 8.615309, 9.56355, 10.5028, 11.4174, 
        12.2524, 12.98885, 13.6086, 14.11504, 14.5221, 14.82897, 15.03891, 
        15.15741, 15.17392, 15.09761, 14.93454, 14.68161, 14.32863, 13.8664, 
        13.31502, 12.6818, 11.96434, 11.15468, 10.28774, 9.375113, 8.407968, 
        7.403144, 6.392777, 5.38462, 4.358415, 3.384574, 2.444584, 1.543404, 
        0.759125, 0.2034, 0.0
    ])

    # 1. Normalize by Chord (175mm)
    chord = 175.0
    x_norm = x_mm / chord
    z_norm = y_mm / chord

    # 2. Create Spline
    # Using UnivariateSpline with a small smoothing factor 's' 
    # to handle the jagged data at the start (1.8 -> 0.6 -> 1.3)
    # This prevents the slope from oscillating wildly.
    camber_spline = UnivariateSpline(x_norm, z_norm, s=0.00001)

    # 3. Calculate Slope (Derivative) at Control Points
    slope_at_control = camber_spline(x_control_points, 1) # 1st derivative
    
    return slope_at_control

# --- 3. AERODYNAMIC SOLVER ---
def solve_for_N(N):
    beta = np.sqrt(1 - M0**2)
    c = 1.0 

    # --- A. GRID GENERATION (Lan's Cosine Spacing) ---
    k_indices = np.arange(1, N + 1)
    theta_k = (2 * k_indices - 1) * np.pi / (2 * N)
    x_vortex = (c / 2.0) * (1 - np.cos(theta_k))

    i_indices = np.arange(1, N + 1)
    theta_i = (i_indices * np.pi) / N
    x_control = (c / 2.0) * (1 - np.cos(theta_i))

    # --- B. INFLUENCE MATRIX ---
    Influence_Matrix = np.zeros((N, N))
    for i in range(N):
        for k in range(N):
            dx = x_control[i] - x_vortex[k]
            if abs(dx) < 1e-12: 
                Influence_Matrix[i, k] = 0 
            else:
                Influence_Matrix[i, k] = 1.0 / (2 * np.pi * dx)

    # --- C. BOUNDARY CONDITION (RHS) ---
    # Use the USER DATA function here
    geometric_slope = get_user_camber_slope(x_control)
    
    RHS = geometric_slope - np.tan(alpha_rad)
    
    # --- D. SOLVE FOR GAMMA ---
    try:
        gamma_w = np.linalg.solve(Influence_Matrix, RHS)
    except np.linalg.LinAlgError:
        return 0 

    # --- E. SUCTION PARAMETER (C) ---
    w_ind_LE = np.dot(Influence_Matrix[0, :], gamma_w)
    slope_LE = geometric_slope[0]
    
    residual = w_ind_LE - (slope_LE - np.tan(alpha_rad))
    C = residual / (N * beta)
    
    # --- F. THRUST COEFFICIENT (c_t) ---
    ct = (np.pi / 2) * beta * (C**2)

    # --- G. INTEGRATE SECTIONAL LIFT (c_l) ---
    integral_sum = np.sum(gamma_w * np.sin(theta_k))
    cl_circ = (2 * np.cos(alpha_rad) / c) * (np.pi / N) * integral_sum
    
    # Total Aerodynamic Lift
    cl_total_aero = cl_circ + ct * np.sin(alpha_rad - slope_LE)

    return cl_total_aero + CL_jet

# --- 4. RUN CONVERGENCE LOOP ---
N_values = [10, 20, 30, 40, 60, 80, 100, 150]
CL_results = []

print(f"{'N':<5} | {'Total CL':<10}")
print("-" * 20)

for N in N_values:
    cl = solve_for_N(N)
    CL_results.append(cl)
    print(f"{N:<5} | {cl:.5f}")

# --- 5. PLOT RESULTS ---
plt.figure(figsize=(10, 6))
plt.plot(N_values, CL_results, 'o-', linewidth=2, color='green')
plt.title(r'Grid Convergence: User Camber Data' + f'\nAlpha={alpha_deg}°, Delta_j={delta_j_deg}°, C_mu={C_mu}')
plt.xlabel('Number of Vortex Panels (N)')
plt.ylabel(r'Total Lift Coefficient ($C_L$)')
plt.grid(True, linestyle='--')
plt.axhline(y=CL_results[-1], color='r', linestyle=':', label=f'Converged ~ {CL_results[-1]:.4f}')
plt.legend()
plt.tight_layout()
plt.show()