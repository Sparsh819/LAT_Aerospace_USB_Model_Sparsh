import numpy as np

def get_2d_induced_velocity(target_point, vortex_point, gamma=1.0, Mach=0.0):
    """
    Calculates the induced velocity (u, w) at a target point (x, z)
    due to a 2D point vortex at vortex_point (xv, zv).

    Applies Prandtl-Glauert compressibility correction.
    """
    x, z = target_point
    xv, zv = vortex_point

    # Compressibility Factor
    if Mach >= 1.0:
        raise ValueError("Linear code supports subsonic flow only (Mach < 1.0).")

    # Beta factor
    beta = np.sqrt(1 - Mach**2)
    beta = 1

    dx = x - xv
    dz = z - zv

    # Compressible radius squared
    r_sq_compressible = dx**2 + (beta * dz)**2

    if r_sq_compressible < 1e-12:
        return np.zeros(2) # Singularity check

    factor = (gamma / (2 * np.pi * r_sq_compressible))

    u = factor * (beta * dz)
    w = -factor * (beta * dx)

    return np.array([u, w])

def compute_usb_matrices(wing_geometry, jet_geometry, Mach_o=0.0, Mach_j=0.0):
    """
    Computes the Aerodynamic Influence Coefficient matrices for a USB configuration
    using the Two-Vortex-Sheet model (Lan & Campbell).

    Returns standard matrices (N_WW, N_WJ) and split jet matrices (Outer/Inner Mach).
    """

    # Unpack Wing Data
    w_vort = wing_geometry['vortices']
    w_cp   = wing_geometry['control_points']
    w_norm = wing_geometry['normals']

    # Unpack Jet Data (Single Surface)
    j_vort = jet_geometry['vortices']
    j_cp   = jet_geometry['control_points']
    j_norm = jet_geometry['normals']
    j_tan  = jet_geometry['tangents']

    Nw = len(w_vort)
    Nj = len(j_vort)

    # --- Initialize Matrices ---
    # Standard Wing Matrices
    N_WW = np.zeros((Nw, Nw))
    N_WJ = np.zeros((Nw, Nj))

    # Jet Surface Matrices - Outer Flow (Mo)
    N_JW_o = np.zeros((Nj, Nw))
    S_JW_o = np.zeros((Nj, Nw))
    N_JJ_o = np.zeros((Nj, Nj))
    S_JJ_o = np.zeros((Nj, Nj))

    # Jet Surface Matrices - Jet Flow (Mj)
    N_JW_j = np.zeros((Nj, Nw))
    S_JW_j = np.zeros((Nj, Nw))
    N_JJ_j = np.zeros((Nj, Nj))
    S_JJ_j = np.zeros((Nj, Nj))

    # --- 1. Compute Wing Control Point Influences (All in Outer Flow Mo) ---
    for i in range(Nw):
        target = w_cp[i]
        n_vec = w_norm[i]

        # Wing on Wing (Mo)
        for k in range(Nw):
            vel = get_2d_induced_velocity(target, w_vort[k], gamma=1.0, Mach=Mach_o)
            N_WW[i, k] = np.dot(vel, n_vec)

        # Jet on Wing (Mo)
        # This represents the influence of the "Outer Jet Sheet" (gamma_o) on the Wing.
        for k in range(Nj):
            vel = get_2d_induced_velocity(target, j_vort[k], gamma=1.0, Mach=Mach_o)
            N_WJ[i, k] = np.dot(vel, n_vec)

    # --- 2. Compute Jet Control Point Influences ---
    for i in range(Nj):
        target = j_cp[i]
        n_vec = j_norm[i]
        t_vec = j_tan[i]

        # --- A. Outer Flow Regime (Uses Mach_o) ---

        # Wing on Jet (Mo)
        for k in range(Nw):
            vel = get_2d_induced_velocity(target, w_vort[k], gamma=1.0, Mach=Mach_o)
            N_JW_o[i, k] = np.dot(vel, n_vec)
            S_JW_o[i, k] = np.dot(vel, t_vec)

        # Jet on Jet (Mo) -> Self-induction of gamma_o on the boundary
        for k in range(Nj):
            vel = get_2d_induced_velocity(target, j_vort[k], gamma=1.0, Mach=Mach_o)
            N_JJ_o[i, k] = np.dot(vel, n_vec)
            S_JJ_o[i, k] = np.dot(vel, t_vec)

        # --- B. Jet Flow Regime (Uses Mach_j) ---

        # Wing on Jet (Mj) -> Wing's influence felt *inside* the jet
        for k in range(Nw):
            vel = get_2d_induced_velocity(target, w_vort[k], gamma=1.0, Mach=Mach_j)
            N_JW_j[i, k] = np.dot(vel, n_vec)
            S_JW_j[i, k] = np.dot(vel, t_vec)

        # Jet on Jet (Mj) -> Self-induction of gamma_j on the boundary
        for k in range(Nj):
            vel = get_2d_induced_velocity(target, j_vort[k], gamma=1.0, Mach=Mach_j)
            N_JJ_j[i, k] = np.dot(vel, n_vec)
            S_JJ_j[i, k] = np.dot(vel, t_vec)

    return {
        "N_WW": N_WW,
        "N_WJ": N_WJ,

        "N_JW_o": N_JW_o,
        "S_JW_o": S_JW_o,
        "N_JJ_o": N_JJ_o,
        "S_JJ_o": S_JJ_o,

        "N_JW_j": N_JW_j,
        "S_JW_j": S_JW_j,
        "N_JJ_j": N_JJ_j,
        "S_JJ_j": S_JJ_j
    }

# --- Geometry Generators ---
def discretize_curve(x_points, z_points):
    """
    Discretizes a generic curve defined by points into vortex panels.
    """
    num_panels = len(x_points) - 1

    vortices = []
    control_points = []
    normals = []
    tangents = []

    for k in range(num_panels):
        p1 = np.array([x_points[k], z_points[k]])
        p2 = np.array([x_points[k+1], z_points[k+1]])

        # Panel Geometry
        panel_vec = p2 - p1
        length = np.linalg.norm(panel_vec)
        unit_tan = panel_vec / length

        # Normal (Standard: 90 deg counter-clockwise from tangent)
        # If curve is L->R, normal points Up.
        unit_norm = np.array([-unit_tan[1], unit_tan[0]])

        # Vortex at 1/4 chord, Control Point at 3/4 chord
        vortex_loc = p1 + 0.25 * panel_vec
        cp_loc = p1 + 0.75 * panel_vec

        vortices.append(vortex_loc)
        control_points.append(cp_loc)
        normals.append(unit_norm)
        tangents.append(unit_tan)

    return {
        'vortices': np.array(vortices),
        'control_points': np.array(control_points),
        'normals': np.array(normals),
        'tangents': np.array(tangents)
    }

def generate_wing_geometry(x_start, x_end, num_panels, camber_func, naca):
    """
    Updated to accept 'naca' argument and pass it to camber_func.
    """
    x_vals = np.linspace(x_start, x_end, num_panels + 1)
    z_vals = camber_func(x_vals, naca) # Now handles array x_vals correctly
    return discretize_curve(x_vals, z_vals)

def generate_single_jet_geometry(x_start, x_end, num_panels, jet_path_func):
    x_vals = np.linspace(x_start, x_end, num_panels + 1)
    z_vals = jet_path_func(x_vals)
    return discretize_curve(x_vals, z_vals)


def solve_usb_3var_system(mats, wing_geom, jet_geom, flow_params):
    """
    Solves for [gamma_wa, gamma_oj, gamma_jj].
    Now includes Jet Entrainment in R1.
    """
    Vo = flow_params['V_o']
    Vj = flow_params['V_j']
    rho_o = flow_params['rho_o']
    rho_j = flow_params['rho_j']
    alpha_rad = np.radians(flow_params['alpha'])

    # Jet Entrainment Velocity Vector (V_ent)
    # If not provided, assume 0 (No entrainment model)
    # V_ent should be a vector [u_e, w_e] or similar.
    V_ent = flow_params.get('V_ent', np.array([0.0, 0.0]))

    Nw = mats['N_WW'].shape[0]
    Nj = mats['N_JJ_o'].shape[0]

    mu = Vo / Vj
    mu_dash = mu
    T = rho_o/rho_j
    T_mu2 = T * mu**2

    w_norm = wing_geom['normals']
    j_norm = jet_geom['normals']
    j_tan  = jet_geom['tangents']

    V_inf_vec = Vo * np.array([np.cos(alpha_rad), np.sin(alpha_rad)])

    # --- Step A: Solve Wing-Alone (gamma_wo) ---
    RHS_wo = np.zeros(Nw)
    for i in range(Nw):
        RHS_wo[i] = -np.dot(V_inf_vec, wing_geom['normals'][i])
    gamma_wo = np.linalg.solve(mats['N_WW'], RHS_wo)



    # ------------------------------------------------------------------
    # Step 1: build RHS of eqs. (24)-(26)
    # ------------------------------------------------------------------
    # Eq. (24):
    # [N_JW]_o * γ_wa + [N_JJ]_o * γ_oj - [N_JJ]_j * γ_jj = RHS1
    # RHS1_i = Vo·n_i (1 - μ') / (Vo·e_i) + (∂φ_wj/∂n)_i - (∂φ_wo/∂n)_i
    # Here ∂φ_wo/∂n on jet is N_JW_o * gamma_wo.
    # You can supply a scaling for (∂φ_wj/∂n) via flow_params if desired.
    #
    RHS1 = np.zeros(Nj)
    # wing-alone normal derivative at jet (outer Mach)
    dphi_wo_dn = mats['N_JW_o'] @ gamma_wo

    # optional scaling for "wj" version; default assume equal to outer
    scale_wj_n = flow_params.get('scale_wj_n', 1.0)
    dphi_wj_dn = scale_wj_n * dphi_wo_dn

    for i in range(Nj):
        n_i = j_norm[i]
        e_i = j_tan[i]
        Vo_dot_n = np.dot(V_inf_vec, n_i)
        Vo_dot_e = np.dot(V_inf_vec, e_i)
        geom_term = Vo_dot_n * (1.0 - mu_dash) / Vo_dot_e
        RHS1[i] = -geom_term + dphi_wj_dn[i] - dphi_wo_dn[i]

    # Eq. (25):
    # -T(μ')^2 [S_JW]_o γ_wa - T(μ')^2 [S_JJ]_o γ_oj + [S_JJ]_j γ_jj = RHS2
    # RHS2_i = -(∂φ_wj/∂s)_i + T(μ')^2 (∂φ_wo/∂s)_i
    #
    RHS2 = np.zeros(Nj)
    dphi_wo_ds = mats['S_JW_o'] @ gamma_wo
    scale_wj_s = flow_params.get('scale_wj_s', 1.0)
    dphi_wj_ds = scale_wj_s * dphi_wo_ds

    for i in range(Nj):
        RHS2[i] = -dphi_wj_ds[i] + T_mu2 * dphi_wo_ds[i]

    # Eq. (26):
    # [N_WW] γ_wa + [N_WJ]_o γ_oj = RHS3
    # RHS3_i = ( V_je · k ) / (V∞ cos α)
    # In 2D, k is the +z direction; use V_ent[1] as w-component.
    #
    Vje_k = V_ent[1]
    RHS3 = np.full(Nw, -Vje_k / (Vo * np.cos(alpha_rad)))

    # ------------------------------------------------------------------
    # Step 2: assemble global linear system A * x = b
    # x = [gamma_wa (Nw), gamma_oj (Nj), gamma_jj (Nj)]
    # ------------------------------------------------------------------
    n_unknowns = Nw + 2 * Nj
    n_eqs      = 2 * Nj + Nw

    A = np.zeros((n_eqs, n_unknowns))
    b = np.zeros(n_eqs)

    # Rows 0..Nj-1 : eq. (24)
    row0 = 0
    A[row0:row0+Nj, 0:Nw]           = mats['N_JW_o']
    A[row0:row0+Nj, Nw:Nw+Nj]       = mats['N_JJ_o']
    A[row0:row0+Nj, Nw+Nj:Nw+2*Nj]  = -mats['N_JJ_j']
    b[row0:row0+Nj] = RHS1

    # Rows Nj..2Nj-1 : eq. (25)
    row1 = Nj
    A[row1:row1+Nj, 0:Nw]           = -T_mu2 * mats['S_JW_o']
    A[row1:row1+Nj, Nw:Nw+Nj]       = -T_mu2 * mats['S_JJ_o']
    A[row1:row1+Nj, Nw+Nj:Nw+2*Nj]  = mats['S_JJ_j']
    b[row1:row1+Nj] = RHS2

    # Rows 2Nj..2Nj+Nw-1 : eq. (26)
    row2 = 2 * Nj
    A[row2:row2+Nw, 0:Nw]           = mats['N_WW']
    A[row2:row2+Nw, Nw:Nw+Nj]       = mats['N_WJ']
    # last Nj columns (gamma_jj) have zero here
    b[row2:row2+Nw] = RHS3

    # ------------------------------------------------------------------
    # Step 3: solve for [gamma_wa, gamma_oj, gamma_jj]
    # ------------------------------------------------------------------
    sol = np.linalg.solve(A, b)

    gamma_wa = sol[0:Nw]
    gamma_oj = sol[Nw:Nw+Nj]
    gamma_jj = sol[Nw+Nj:Nw+2*Nj]

    return {
        "gamma_wo": gamma_wo,   # wing-alone
        "gamma_wa": gamma_wa,   # additional wing vortices
        "gamma_oj": gamma_oj,   # outer jet sheet
        "gamma_jj": gamma_jj    # inner jet sheet
    }

# --- Main Execution Block ---
if __name__ == "__main__":
    print("Initializing 2D USB Analysis...")

    # 1. Define Airfoil Geometry (4 digit NACA AIRFOIL) - VECTORIZED
    def camber_profile(x, naca):
        # Extract digits
        P_digit = (naca // 100) % 10
        M_digit = (naca // 1000) % 10

        # Convert to coefficients (e.g., 4 -> 0.4, 4 -> 0.04)
        p = P_digit / 10.0
        m = M_digit / 100.0

        # Initialize Output Array
        zc = np.zeros_like(x)

        # Avoid division by zero for symmetric airfoils (00xx)
        if p == 0:
            return zc

        # Create Masks for Forward and Aft sections
        # This replaces the scalar "if x < P" logic
        mask_front = (x <= p)
        mask_back = (x > p)

        # Forward Camber Calculation
        if np.any(mask_front):
            # Formula: (m/p^2) * (2px - x^2)
            term1 = m / (p**2)
            term2 = 2 * p * x[mask_front] - x[mask_front]**2
            zc[mask_front] = term1 * term2

        # Aft Camber Calculation
        if np.any(mask_back):
            # Formula: (m/(1-p)^2) * ((1-2p) + 2px - x^2)
            term1 = m / ((1 - p)**2)
            term2 = (1 - 2*p) + 2 * p * x[mask_back] - x[mask_back]**2
            zc[mask_back] = term1 * term2

        return zc

    # Jet Profile Wrapper
    # This assumes the jet follows the same NACA 4412 profile + offset
    def jet_profile(x):
        return camber_profile(x, 4412) + 0.01

    # 2. Generate Geometry
    print("Generating Wing Geometry...")
    # Passing '4412' as the naca argument
    wing_geom = generate_wing_geometry(0.0, 1.0, 100, camber_profile, 4412)

    print("Generating Jet Geometry (Single Surface)...")
    # Jet profile wrapper already includes the NACA code internally
    jet_geom = generate_single_jet_geometry(0.0, 1.0, 100, jet_profile)

    # 3. Compute Matrices
    # Mach Nonuniformity: Mo=0.2, Mj=0.7
    print("Computing Matrices for Mo=0.2, Mj=0.7 ...")
    mats = compute_usb_matrices(wing_geom, jet_geom, Mach_o=0.2, Mach_j=0.7)


    params = {
        'V_o': 90, 'V_j': 100, 'rho_o': 1.225, 'rho_j': 1.225, 'alpha': 0,
        'V_ent': np.array([0.0, -2.0]) # Example: Small downwash due to entrainment
    }

    gamma = solve_usb_3var_system(mats, wing_geom, jet_geom, params)

    # integrand_Cl = gamma_wo*np.cos(params['alpha'] - np.atan(wing_geom['tangents'][:,1]/wing_geom['tangents'][:,0]))/params['V_o']

    # Cl = (2*np.cos( params['alpha'] )/1) * np.sum(integrand_Cl)

    Cl = 2*np.sum(gamma['gamma_wo'])/(params['V_o']*1)


    print(Cl)

    gamma_wo = gamma['gamma_wo']
    gamma_wa = gamma['gamma_wa']
    gamma_w  = gamma_wo + gamma_wa   # total wing vortex distribution

    tangents = wing_geom['tangents']          # shape (Nw, 2) = (tx, tz)
    theta    = np.arctan2(tangents[:,1],      # θ̄(x): local camberline angle
                        tangents[:,0])      # atan2(tz, tx)
    alpha_rad = np.radians(params['alpha'])

    Nw = gamma_w.size
    c  = 18.0                       # chord length in your setup
    dx = c / Nw
    Vo = params['V_o']


    # print("\n=== Geometry Check ===")
    # print("First 5 tangents (tx, tz):")
    # print(wing_geom['tangents'][:5])
    # print("\nFirst 5 normals (nx, nz):")
    # print(wing_geom['normals'][:5])



    # print("\n=== Vortex Strength Signs ===")
    # print(f"gamma_wo: mean = {gamma_wo.mean():.6f}, mean sign = {np.sign(gamma_wo).mean():.2f}")
    # print(f"gamma_wa: mean = {gamma_wa.mean():.6f}, mean sign = {np.sign(gamma_wa).mean():.2f}")
    # print(f"gamma_w:  mean = {gamma_w.mean():.6f}, mean sign = {np.sign(gamma_w).mean():.2f}")

    # print(f"\ngamma_wo min/max: [{gamma_wo.min():.6f}, {gamma_wo.max():.6f}]")
    # print(f"gamma_w  min/max: [{gamma_w.min():.6f}, {gamma_w.max():.6f}]")

    # integrand at each panel
    integrand_Cl = gamma_w * np.cos(alpha_rad - theta) / Vo
    integrand_Cd = gamma_w * np.sin(alpha_rad - theta) / Vo

    # approximate ∫_0^c γ_w(x) cos(α-θ̄) dx
    integral_Cl = np.sum(integrand_Cl)
    integral_Cd = np.sum(integrand_Cd)

    Cl_circ = 2.0 * np.cos(alpha_rad) * integral_Cl  # circulation lift term
    Cd_circ = 2.0 * np.cos(alpha_rad) * integral_Cd  # circulation drag term

    Ct = 0.0  # until you implement Lan's suction parameter and Ct

    theta_LE = theta[0]  # leading-edge camber angle (first panel)
    Cl_total = Cl_circ + Ct * np.sin(alpha_rad - theta_LE)
    Cd_total = Cd_circ - Ct * np.cos(alpha_rad - theta_LE)


    print("Cl_total =", Cl_total)
    print("Cd_total =", Cd_total)