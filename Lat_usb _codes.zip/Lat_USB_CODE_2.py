import numpy as np
import matplotlib.pyplot as plt

class USB_Solver:
    def __init__(self, naca='4412', n_wing=20, n_jet=20, chord=1.0):
        self.naca = naca
        self.Nw = n_wing
        self.Nj = n_jet
        self.c = chord
        
        # Geometry State
        self.wing_geom = None
        self.jet_geom = None
        
        # Solution State
        self.gamma_solution = None
        self.forces = {}

    def get_2d_induced_velocity(self, target_point, vortex_point, gamma=1.0, Mach=0.0):
        """
        Calculates (u, w) at target due to point vortex.
        Includes Prandtl-Glauert compressibility beta factor.
        """
        x, z = target_point
        xv, zv = vortex_point
        
        # PG Correction
        if Mach >= 1.0: beta = 0.1 # Avoid crash, though physics invalid
        else: beta = np.sqrt(1 - Mach**2)
            
        dx = x - xv
        dz = z - zv
        
        # Compressible radius squared
        # Note: Vertical component is stretched by beta in P-G rule
        r_sq = dx**2 + (beta * dz)**2
        
        if r_sq < 1e-10: return np.zeros(2) # Singularity cutoff
        
        # Biot-Savart with compressibility
        factor = (gamma / (2 * np.pi * r_sq))
        u = factor * (beta * dz)
        w = -factor * (beta * dx)
        
        return np.array([u, w])

    def discretize_curve(self, x_points, z_points):
        """
        Converts points to panel objects with COSINE SPACING logic applied externally.
        """
        num_panels = len(x_points) - 1
        vortices, cps, normals, tangents, lengths = [], [], [], [], []

        for k in range(num_panels):
            p1 = np.array([x_points[k], z_points[k]])
            p2 = np.array([x_points[k+1], z_points[k+1]])
            
            vec = p2 - p1
            L = np.linalg.norm(vec)
            unit_tan = vec / L
            # Normal: Rotate tangent 90 deg CCW (assuming L->R definition)
            unit_norm = np.array([-unit_tan[1], unit_tan[0]])
            
            # Vortex at 1/4 chord, CP at 3/4 chord
            vortices.append(p1 + 0.25 * vec)
            cps.append(p1 + 0.75 * vec)
            normals.append(unit_norm)
            tangents.append(unit_tan)
            lengths.append(L)

        return {
            'vortices': np.array(vortices),
            'control_points': np.array(cps),
            'normals': np.array(normals),
            'tangents': np.array(tangents),
            'lengths': np.array(lengths),
            'p_start': np.column_stack((x_points[:-1], z_points[:-1])),
            'p_end':   np.column_stack((x_points[1:], z_points[1:]))
        }

    def generate_cosine_x(self, x_start, x_end, n_panels):
        """
        Generates x-coordinates using Cosine Spacing (Multhopp/Lan)
        x = 0.5*(1 - cos(theta))
        """
        theta = np.linspace(0, np.pi, n_panels + 1)
        x_norm = 0.5 * (1 - np.cos(theta))
        return x_start + (x_end - x_start) * x_norm

    def get_camber_z(self, x_vals):
        """ Vectorized NACA 4-digit camber """
        digits = str(self.naca)
        m = int(digits[0])/100.0
        p = int(digits[1])/10.0
        
        z = np.zeros_like(x_vals)
        if m == 0: return z
        
        front = x_vals <= p
        back = x_vals > p
        
        z[front] = (m/p**2) * (2*p*x_vals[front] - x_vals[front]**2)
        z[back]  = (m/(1-p)**2) * ((1-2*p) + 2*p*x_vals[back] - x_vals[back]**2)
        return z

    def setup_geometry(self, jet_deflection_deg=0.0, jet_thickness=0.01):
        # 1. Wing Geometry (Cosine Spacing)
        x_w = self.generate_cosine_x(0, self.c, self.Nw)
        z_w = self.get_camber_z(x_w)
        self.wing_geom = self.discretize_curve(x_w, z_w)
        
        # 2. Jet Geometry (Initial Guess)
        # Starts at Trailing Edge of wing, length approx 2*chord for wake
        te_x, te_z = x_w[-1], z_w[-1]
        
        # Linear spacing often more stable for wake relaxation than cosine
        jet_len = 3.0 * self.c
        x_j = np.linspace(te_x, te_x + jet_len, self.Nj + 1)
        
        # Initial deflection path
        delta_rad = np.radians(jet_deflection_deg)
        z_j = te_z + (x_j - te_x) * np.tan(-delta_rad) # Downward deflection negative z
        
        # Apply thickness offset if modeling top/bottom sheet, 
        # but single sheet model assumes mean line.
        # We shift slightly to avoid numerical collision with TE if necessary
        x_j[0] += 1e-4 
        
        self.jet_geom = self.discretize_curve(x_j, z_j)
        self.jet_thickness = jet_thickness # Store for C_mu calc if needed

    def compute_matrices(self, Mo, Mj):
        w_g = self.wing_geom
        j_g = self.jet_geom
        Nw, Nj = self.Nw, self.Nj
        
        # Helper to build sub-matrices
        def build_submatrix(targets_g, sources_g, measure_norm=True, M=0.0):
            # targets_g: geometry dict of targets
            # sources_g: geometry dict of sources
            Nt = len(targets_g['control_points'])
            Ns = len(sources_g['vortices'])
            mat = np.zeros((Nt, Ns))
            
            for i in range(Nt):
                t_point = targets_g['control_points'][i]
                n_vec   = targets_g['normals'][i]
                t_vec   = targets_g['tangents'][i]
                vec_measure = n_vec if measure_norm else t_vec
                
                for k in range(Ns):
                    s_point = sources_g['vortices'][k]
                    vel = self.get_2d_induced_velocity(t_point, s_point, 1.0, M)
                    mat[i,k] = np.dot(vel, vec_measure)
            return mat

        mats = {}
        # Wing Influence (Outer Flow Mo)
        mats['N_WW'] = build_submatrix(w_g, w_g, True, Mo)
        mats['N_WJ'] = build_submatrix(w_g, j_g, True, Mo)
        
        # Jet Influence (Outer Mo & Inner Mj)
        # Normal components
        mats['N_JW_o'] = build_submatrix(j_g, w_g, True, Mo)
        mats['N_JJ_o'] = build_submatrix(j_g, j_g, True, Mo)
        mats['N_JJ_j'] = build_submatrix(j_g, j_g, True, Mj)
        
        # Tangential components (for Pressure/Bernoulli eq)
        mats['S_JW_o'] = build_submatrix(j_g, w_g, False, Mo)
        mats['S_JJ_o'] = build_submatrix(j_g, j_g, False, Mo)
        mats['S_JJ_j'] = build_submatrix(j_g, j_g, False, Mj)
        
        return mats

    def solve_linear_system(self, mats, params):
        Vo = params['V_o']
        Vj = params['V_j']
        rho_o = params['rho_o']
        rho_j = params['rho_j']
        alpha = np.radians(params['alpha'])
        
        Nw, Nj = self.Nw, self.Nj
        
        # Parameters
        mu = Vo / Vj
        T_dens = rho_o / rho_j
        # Constant in Eq 25 (Pressure boundary condition)
        # Factor = (rho_o * Vo^2) / (rho_j * Vj^2) * (Vj/Vo)^2 ?? 
        # Derived from Bernoulli: coeff is T * mu^2
        Coeff_P = T_dens * (mu**2)

        # Freestream Vector
        Vinf = Vo * np.array([np.cos(alpha), np.sin(alpha)])
        
        # --- RHS Vectors ---
        
        # 1. Wing BC: Normal velocity is zero
        # RHS = - Vinf dot n
        RHS_W = np.zeros(Nw)
        for i in range(Nw):
            RHS_W[i] = -np.dot(Vinf, self.wing_geom['normals'][i])
            
        # 2. Jet Kinematic BC (Eq 24)
        # (V_inf + u_ind) dot n = 0 (Simplified)
        # More complex form in paper: accounts for jump across sheet
        # Here we approximate: Total normal velocity on sheet center = 0
        RHS_J_Kin = np.zeros(Nj)
        for i in range(Nj):
            # The paper has specific complex terms for mismatching Mach lines
            # For this implementation, we enforce flow tangency on the weighted sheet
            RHS_J_Kin[i] = -np.dot(Vinf, self.jet_geom['normals'][i])

        # 3. Jet Dynamic BC (Eq 25)
        # Pressure difference balance. 
        # (u_j * gamma_j) - T_mu2 * (u_o * gamma_o) terms...
        # In linearized theory, RHS is often 0 or curvature dependent.
        # We will set RHS to zero and let the LHS matrices (S_JJ) handle the circulation relation
        RHS_J_Dyn = np.zeros(Nj)
        
        # --- Matrix Assembly ---
        # System: [Gamma_w (Nw), Gamma_oj (Nj), Gamma_jj (Nj)]
        
        N_tot = Nw + 2*Nj
        A = np.zeros((N_tot, N_tot))
        b = np.zeros(N_tot)
        
        # Block 1: Wing Boundary Condition
        # N_WW * Gw + N_WJ * Goj + 0 * Gjj = RHS_W
        # Note: Inner jet vorticity (Gjj) doesn't affect Wing in Outer flow model usually,
        # unless N_WJ accounts for net gamma. The paper separates them.
        # Typically Wing sees Gamma_net = Gamma_oj - Gamma_jj ??
        # Lan's paper treats them as two distinct sheets for math.
        
        A[0:Nw, 0:Nw]       = mats['N_WW']
        A[0:Nw, Nw:Nw+Nj]   = mats['N_WJ'] # Influence of outer sheet
        b[0:Nw]             = RHS_W
        
        # Block 2: Jet Kinematic BC (Eq 24 in paper)
        # N_JW_o * Gw + N_JJ_o * Goj - N_JJ_j * Gjj = ...
        idx_j1 = Nw
        A[idx_j1:idx_j1+Nj, 0:Nw]       = mats['N_JW_o']
        A[idx_j1:idx_j1+Nj, Nw:Nw+Nj]   = mats['N_JJ_o']
        A[idx_j1:idx_j1+Nj, Nw+Nj:]     = -mats['N_JJ_j'] # Sign diff due to direction?
        b[idx_j1:idx_j1+Nj]             = RHS_J_Kin
        
        # Block 3: Jet Dynamic BC (Eq 25 in paper)
        # Tangential velocities relation
        idx_j2 = Nw + Nj
        A[idx_j2:idx_j2+Nj, 0:Nw]       = -Coeff_P * mats['S_JW_o']
        A[idx_j2:idx_j2+Nj, Nw:Nw+Nj]   = -Coeff_P * mats['S_JJ_o']
        A[idx_j2:idx_j2+Nj, Nw+Nj:]     = mats['S_JJ_j']
        b[idx_j2:idx_j2+Nj]             = RHS_J_Dyn
        
        # Solve
        x_sol = np.linalg.solve(A, b)
        
        return {
            'gamma_w': x_sol[0:Nw],
            'gamma_oj': x_sol[Nw:Nw+Nj],
            'gamma_jj': x_sol[Nw+Nj:],
            'gamma_jet_net': x_sol[Nw:Nw+Nj] - x_sol[Nw+Nj:]
        }

    def update_jet_shape(self, gammas, params):
        """
        Relaxation Step: Align jet panels with the local velocity vector.
        Corresponds to the "Jet Path Curvature" requirement.
        """
        Vo = params['V_o']
        alpha = np.radians(params['alpha'])
        
        # Reconstruct coordinates
        x_j = np.zeros(self.Nj + 1)
        z_j = np.zeros(self.Nj + 1)
        
        # Start at Wing TE
        x_j[0] = self.wing_geom['p_end'][-1, 0]
        z_j[0] = self.wing_geom['p_end'][-1, 1]
        
        Vinf = Vo * np.array([np.cos(alpha), np.sin(alpha)])
        
        for k in range(self.Nj):
            # Current panel cp
            cp = self.jet_geom['control_points'][k]
            
            # Calculate induced velocity at this CP from ALL vortices
            # (Wing + Old Jet)
            V_ind = np.zeros(2)
            
            # 1. Wing Contribution
            for i in range(self.Nw):
                V_ind += self.get_2d_induced_velocity(cp, self.wing_geom['vortices'][i], gammas['gamma_w'][i])
            
            # 2. Jet Contribution (Net)
            for i in range(self.Nj):
                V_ind += self.get_2d_induced_velocity(cp, self.jet_geom['vortices'][i], gammas['gamma_jet_net'][i])
                
            V_total = Vinf + V_ind
            
            # New slope dy/dx = w / u
            slope = V_total[1] / V_total[0]
            
            # Integrate to find next point
            dx = self.jet_geom['lengths'][k] # approximate preservation of panel length
            # Ideally preserve x-spacing:
            dx_proj = self.jet_geom['p_end'][k,0] - self.jet_geom['p_start'][k,0]
            
            x_j[k+1] = x_j[k] + dx_proj
            z_j[k+1] = z_j[k] + slope * dx_proj
            
        # Update Geometry with relaxation
        # Relaxation factor to prevent oscillation
        omega = 0.6
        
        # Current z points
        current_z_start = self.jet_geom['p_start'][:,1]
        current_z_end = self.jet_geom['p_end'][:,1]
        current_z = np.concatenate(([current_z_start[0]], current_z_end))
        
        new_z = (1 - omega) * current_z + omega * z_j
        
        self.jet_geom = self.discretize_curve(x_j, new_z)

    def calculate_forces(self, params, C_mu, t_j):
        """
        Calculates Cl, Cd, Cm, Ct (Suction), and Jet Reaction.
        """
        gammas = self.gamma_solution
        rho_o = params['rho_o']
        Vo = params['V_o']
        alpha = np.radians(params['alpha'])
        
        # 1. Circulation Lift & Drag (Kutta-Joukowski on Wing)
        # Cl = 2 * sum(gamma) / (Vo * c)
        L_circ = rho_o * Vo * np.sum(gammas['gamma_w'])
        D_ind  = 0.0 # In 2D, Induced Drag is 0 unless we account for energy in wake or separated flow
        
        # 2. Leading Edge Suction (Ct)
        # Lan's Method / Multhopp: C_s ~ gamma_1 / sqrt(x1)
        # Get first panel properties
        g1 = gammas['gamma_w'][0] # Vorticity of first panel
        x1 = self.wing_geom['control_points'][0, 0] # dist from LE
        
        # Normalize: gamma in code is usually Circulation (Velocity * Length)
        # Convert to local vortex sheet strength: gamma(x) = Gamma / dx
        dx1 = self.wing_geom['lengths'][0]
        sheet_strength_1 = g1 / dx1
        
        # Lan's singularity parameter C (Eq 41 approx)
        # C = lim (x->0) gamma(x) * sqrt(x)
        C_param = sheet_strength_1 * np.sqrt(x1)
        
        # Eq 42/43: ct = (pi/2) * sqrt(1-M^2) * C^2
        beta = np.sqrt(1 - params.get('Mach_o', 0)**2)
        ct = (np.pi / 2.0) * beta * (C_param**2)
        
        # Ct contribution to Lift and Drag
        # Acts parallel to chord line at LE.
        # Rotate to wind axes.
        # Force F_t = q * c * ct
        # L_t = F_t * sin(alpha)
        # D_t = -F_t * cos(alpha) (Thrust reduces drag)
        q = 0.5 * rho_o * Vo**2
        F_suc = ct * self.c * q
        
        L_suc = F_suc * np.sin(alpha)
        D_suc = -F_suc * np.cos(alpha)

        # 3. Jet Reaction Forces (L_j, D_j)
        # Momentum Thrust: T = mass_flow * Vj = rho_j * A_j * Vj^2
        # C_mu = T / (q * c)
        # We need the angle of the jet at the trailing edge.
        # Get slope of the first jet panel
        jet_tan = self.jet_geom['tangents'][0]
        theta_j = np.arctan2(jet_tan[1], jet_tan[0])
        
        # Deflection relative to freestream
        delta_total = theta_j - alpha
        
        Thrust = C_mu * q * self.c
        L_jet = Thrust * np.sin(theta_j) # Vertical component
        D_jet = -Thrust * np.cos(theta_j) # Horizontal component (Thrust is negative drag)
        
        # 4. Pitching Moment (Cm) about LE (0,0)
        # Moment = - sum( Force_i * x_i )
        # Force_i = rho * Vo * gamma_i
        # Cm = Moment / (q * c^2)
        
        Moment_LE = 0
        for i in range(self.Nw):
            x_cp = self.wing_geom['control_points'][i, 0]
            dL = rho_o * Vo * gammas['gamma_w'][i] # Lift on panel
            Moment_LE -= dL * x_cp
            
        Cm_circ = Moment_LE / (q * self.c**2)
        
        # Coefficients
        Cl_circ = L_circ / (q * self.c)
        Cl_total = Cl_circ + (L_suc / (q * self.c)) + (L_jet / (q * self.c))
        Cd_total = (D_suc / (q * self.c)) + (D_jet / (q * self.c)) # + Induced Drag if 3D
        
        return {
            "Cl": Cl_total,
            "Cd": Cd_total,
            "Cm": Cm_circ,
            "Ct": ct,
            "Theta_Jet_TE": np.degrees(theta_j)
        }

    def run(self, params, C_mu, t_j_ratio, max_iter=5):
        """
        Main execution loop with wake relaxation.
        """
        print(f"--- Running Solver (C_mu={C_mu}, alpha={params['alpha']}) ---")
        
        # Initialize Geometry
        self.setup_geometry(jet_deflection_deg=30.0, jet_thickness=t_j_ratio*self.c)
        
        # Derived Velocities from C_mu
        # C_mu = 2 * (rho_j/rho_o) * (Vj/Vo)^2 * (t_j/c)
        # Assume rho_j = rho_o for simplicity unless specified
        # (Vj/Vo)^2 = C_mu / (2 * t_j/c)
        vel_ratio_sq = C_mu / (2 * t_j_ratio)
        if vel_ratio_sq < 0: vel_ratio_sq = 0.1 # Safety
        V_ratio = np.sqrt(vel_ratio_sq)
        
        params['V_j'] = params['V_o'] * V_ratio
        
        print(f"   Calculated Vj/Vo: {V_ratio:.3f}")
        
        for it in range(max_iter):
            # 1. Compute Matrices (Geometry changes every iter)
            mats = self.compute_matrices(params.get('Mach_o', 0), params.get('Mach_j', 0))
            
            # 2. Solve Linear System
            self.gamma_solution = self.solve_linear_system(mats, params)
            
            # 3. Update Jet Shape
            if it < max_iter - 1:
                self.update_jet_shape(self.gamma_solution, params)
                
        # 4. Final Forces
        self.forces = self.calculate_forces(params, C_mu, t_j_ratio)
        
        print(f"   Converged: Cl={self.forces['Cl']:.4f}, Cm={self.forces['Cm']:.4f}")
        return self.forces


# --- Test Cases ---

def test_case_1_thin_jet():
    """
    Test Case 1: Replication of Thin Jet (Das Theory comparison).
    High Vj/Vo ratio effectively simulates thin jet physics if Tj is small.
    """
    print("\n=== Test Case 1: Thin Jet Validation ===")
    solver = USB_Solver(naca='0012', n_wing=30, n_jet=30) # Symmetric for validation
    
    params = {
        'V_o': 50.0, 'rho_o': 1.225, 'rho_j': 1.225, 'alpha': 0.0,
        'Mach_o': 0.0, 'Mach_j': 0.0 # Incompressible for validation
    }
    
    # C_mu values to sweep
    cmus = [0.1, 1.0, 3.297]
    results = []
    
    for cmu in cmus:
        # Small thickness, high velocity -> High momentum, Thin jet
        f = solver.run(params, C_mu=cmu, t_j_ratio=0.05, max_iter=5)
        results.append(f['Cl'])
        
    print("\nResults Summary (C_mu vs Cl):")
    for c, l in zip(cmus, results):
        print(f"C_mu: {c:.1f} -> Cl: {l:.4f}")

def test_case_2_thick_jet():
    """
    Test Case 2: Thick Jet Effect (Fig 8 Curve 1).
    Varying jet thickness ratio.
    """
    print("\n=== Test Case 2: Thick Jet Effect ===")
    solver = USB_Solver(naca='4412', n_wing=30, n_jet=30)
    
    params = { 'V_o': 50.0, 'rho_o': 1.225, 'rho_j': 1.225, 'alpha': 0.0 ,'Mach_o': 0.3, 'Mach_j': 0.3  }
    
    thicknesses = [0.05, 0.1, 0.2, 0.3]
    cl_results = []
    
    for t in thicknesses:
        # Constant C_T (Thrust Coeff) implies velocity drops as area increases
        f = solver.run(params, C_mu=0.2, t_j_ratio=t, max_iter=5)
        cl_results.append(f['Cl'])

    print("\nResults Summary (Thickness t/c vs Cl):")
    for t, l in zip(thicknesses, cl_results):
        print(f"t/c: {t:.2f} -> Cl: {l:.4f}")
        
    # Simple Plot
    plt.figure()
    plt.plot(thicknesses, cl_results, 'o-')
    plt.title("Effect of Jet Thickness on Lift (Mo=0.3, alpha=5, Cmu=0.2)")
    plt.xlabel("Jet Thickness t/c")
    plt.ylabel("Lift Coefficient Cl")
    plt.grid(True)
    plt.show()

if __name__ == "__main__":
    test_case_1_thin_jet()
    test_case_2_thick_jet()