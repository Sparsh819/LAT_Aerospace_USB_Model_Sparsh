import numpy as np
import matplotlib.pyplot as plt

def generate_s1223_camber(x):
    """
    Approximates the S1223 mean camber line.
    S1223 has a very high camber (~8-9%) peaking near 40-50% chord.
    We use a polynomial fit to replicate the shape seen in your image.
    """
    # These coefficients approximate the S1223 camber line shape
    # (Starting at 0,0, peaking around x=0.45, ending at 1,0)
    # Based on general high-lift airfoil curvature.
    return 0.36 * x * (1 - x) * (1 + 0.5 * x) 

def rotate_point(origin, point, angle_deg):
    """
    Rotates a point counterclockwise by a given angle around a given origin.
    """
    angle_rad = np.radians(angle_deg)
    ox, oy = origin
    px, py = point

    qx = ox + np.cos(angle_rad) * (px - ox) - np.sin(angle_rad) * (py - oy)
    qy = oy + np.sin(angle_rad) * (px - ox) + np.cos(angle_rad) * (py - oy)
    return qx, qy

# --- Parameters ---
chord_length_mm = 250.0   # Derived from "70% is 175mm" -> 175 / 0.7 = 250
jet_thickness_mm = 82.0
delta_j = -60.0           # Flap deflection angle in degrees (downward)
hinge_x_pct = 0.7         # Hinge location as percentage of chord

# Normalized parameters
t_c = jet_thickness_mm / chord_length_mm
x_hinge = hinge_x_pct

# --- Generate Data Points ---
# 1. Camber Line
x_camber = np.linspace(0, 1.0, 200)
z_camber = generate_s1223_camber(x_camber)

# Find max camber height to position the jet tangentially
max_camber_z = np.max(z_camber)
max_camber_idx = np.argmax(z_camber)
max_camber_x = x_camber[max_camber_idx]

# 2. Jet Geometry Construction
# The jet lower surface is tangential to the camber max.
# This means the flat part of the jet sits at z = max_camber_z.

# Define the length of the jet to plot (e.g., up to 1.25c)
x_jet_end = 1.25

# -- Lower Surface --
# Part A: Horizontal (Leading Edge to Hinge)
x_jet_lower_flat = np.linspace(0, x_hinge, 100)
z_jet_lower_flat = np.full_like(x_jet_lower_flat, max_camber_z)

# Part B: Angled (Hinge to End)
# Hinge point for lower surface
hinge_pt_lower = (x_hinge, max_camber_z)

# Generate points as if they were flat, then rotate them
x_jet_lower_angled_raw = np.linspace(x_hinge, x_jet_end, 50)
z_jet_lower_angled_raw = np.full_like(x_jet_lower_angled_raw, max_camber_z)

x_jet_lower_bent = []
z_jet_lower_bent = []

for i in range(len(x_jet_lower_angled_raw)):
    px, py = x_jet_lower_angled_raw[i], z_jet_lower_angled_raw[i]
    rx, ry = rotate_point(hinge_pt_lower, (px, py), delta_j)
    x_jet_lower_bent.append(rx)
    z_jet_lower_bent.append(ry)

# Combine Lower Surface
x_jet_lower = np.concatenate([x_jet_lower_flat, x_jet_lower_bent])
z_jet_lower = np.concatenate([z_jet_lower_flat, z_jet_lower_bent])

# -- Upper Surface --
# Offset by thickness (t_c)
z_jet_upper_flat_val = max_camber_z + t_c

# Part A: Horizontal
x_jet_upper_flat = np.linspace(0, x_hinge, 100)
z_jet_upper_flat = np.full_like(x_jet_upper_flat, z_jet_upper_flat_val)

# Part B: Angled
# Hinge point for upper surface (it pivots around the same x-plane but at its own height)
# Note: Physically, the whole block rotates around one hinge axis. 
# Typically the hinge is on the chord line or lower surface.
# Based on your image, the thickness remains constant perpendicular to the flow.
# We rotate the upper points around the LOWER hinge point to maintain the solid block shape.

x_jet_upper_angled_raw = np.linspace(x_hinge, x_jet_end, 50)
z_jet_upper_angled_raw = np.full_like(x_jet_upper_angled_raw, z_jet_upper_flat_val)

x_jet_upper_bent = []
z_jet_upper_bent = []

for i in range(len(x_jet_upper_angled_raw)):
    px, py = x_jet_upper_angled_raw[i], z_jet_upper_angled_raw[i]
    # Rotating around the SAME hinge point (lower surface hinge) ensures the block bends together
    rx, ry = rotate_point(hinge_pt_lower, (px, py), delta_j)
    x_jet_upper_bent.append(rx)
    z_jet_upper_bent.append(ry)

# Combine Upper Surface
x_jet_upper = np.concatenate([x_jet_upper_flat, x_jet_upper_bent])
z_jet_upper = np.concatenate([z_jet_upper_flat, z_jet_upper_bent])


# --- Plotting ---
plt.figure(figsize=(10, 5))

# Plot Camber Line
plt.plot(x_camber, z_camber, color='black', linewidth=2, label='S1223 Camber Line')

# Plot Jet Path (Lower)
plt.plot(x_jet_lower, z_jet_lower, color='red', linewidth=2, label='Rectangular Jet Path')

# Plot Jet Path (Upper) - Optional, to show the thickness clearly
plt.plot(x_jet_upper, z_jet_upper, color='red', linewidth=2, linestyle='--')

# Fill the jet area to make it look like a solid "rectangular" stream
plt.fill_between(x_jet_lower, z_jet_lower, z_jet_upper, color='red', alpha=0.1)

# Annotations & Formatting
plt.title(f'S1223 Camber vs Rectangular Jet (Thickness={jet_thickness_mm}mm, $\delta_j$={delta_j}°)')
plt.xlabel('x/c')
plt.ylabel('z/c')
plt.axis('equal') # Crucial to see the real angles and thickness
plt.grid(True)
plt.legend()

# Set limits similar to your image
plt.xlim(-0.05, 1.3)
plt.ylim(-0.4, 0.5)

plt.show()