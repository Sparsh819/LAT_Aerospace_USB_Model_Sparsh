import tkinter as tk
from tkinter import ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import numpy as np
from scipy.interpolate import interp1d

# ==========================================
# PART 1: PHYSICS ENGINE
# ==========================================

def load_s1223_coords():
    # S1223 Coordinates
    data = """1.00000 0.00000
    0.99838 0.00126
    0.99417 0.00494
    0.98825 0.01037
    0.98075 0.01646
    0.97111 0.02250
    0.95884 0.02853
    0.94389 0.03476
    0.92639 0.04116
    0.90641 0.04768
    0.88406 0.05427
    0.85947 0.06089
    0.83277 0.06749
    0.80412 0.07402
    0.77369 0.08044
    0.74166 0.08671
    0.70823 0.09277
    0.67360 0.09859
    0.63798 0.10412
    0.60158 0.10935
    0.56465 0.11425
    0.52744 0.11881
    0.49025 0.12303
    0.45340 0.12683
    0.41721 0.13011
    0.38193 0.13271
    0.34777 0.13447
    0.31488 0.13526
    0.28347 0.13505
    0.25370 0.13346
    0.22541 0.13037
    0.19846 0.12594
    0.17286 0.12026
    0.14863 0.11355
    0.12591 0.10598
    0.10482 0.09770
    0.08545 0.08879
    0.06789 0.07940
    0.05223 0.06965
    0.03855 0.05968
    0.02694 0.04966
    0.01755 0.03961
    0.01028 0.02954
    0.00495 0.01969
    0.00155 0.01033
    0.00005 0.00178
    0.00044 -0.00561
    0.00264 -0.01120
    0.00789 -0.01427
    0.01718 -0.01550
    0.03006 -0.01584
    0.04627 -0.01532
    0.06561 -0.01404
    0.08787 -0.01202
    0.11282 -0.00925
    0.14020 -0.00563
    0.17006 -0.00075
    0.20278 0.00535
    0.23840 0.01213
    0.27673 0.01928
    0.31750 0.02652
    0.36044 0.03358
    0.40519 0.04021
    0.45139 0.04618
    0.49860 0.05129
    0.54639 0.05534
    0.59428 0.05820
    0.64176 0.05976
    0.68832 0.05994
    0.73344 0.05872
    0.77660 0.05612
    0.81729 0.05219
    0.85500 0.04706
    0.88928 0.04088
    0.91966 0.03387
    0.94573 0.02624
    0.96693 0.01822
    0.98255 0.01060
    0.99268 0.00468
    0.99825 0.00115
    1.00000 0.00000"""
    coords = []
    for line in data.split('\n'):
        if line.strip():
            coords.append([float(x) for x in line.split()])
    return np.array(coords)

def rotate_points(points, angle_deg, center=(0,0)):
    rad = np.radians(angle_deg)
    c, s = np.cos(rad), np.sin(rad)
    ox, oy = center
    px = points[:, 0] - ox
    py = points[:, 1] - oy
    qx = ox + c * px - s * py
    qy = oy + s * px + c * py
    return np.column_stack((qx, qy))

def discretize_geometry(points):
    panels = []
    for i in range(len(points) - 1):
        p1 = points[i]
        p2 = points[i+1]
        vec = p2 - p1
        length = np.linalg.norm(vec)
        if length < 1e-9: continue
        tangent = vec / length
        normal = np.array([-tangent[1], tangent[0]]) 
        midpoint = p1 + 0.5 * vec
        panels.append({
            'p1': p1, 'p2': p2,
            'center': midpoint,
            'normal': normal,
            'tangent': tangent,
            'length': length
        })
    return panels

def get_camber_line_y_at_x(x_loc, raw_coords):
    min_x_idx = np.argmin(raw_coords[:, 0]) 
    upper = raw_coords[:min_x_idx+1]
    lower = raw_coords[min_x_idx:]
    if upper[0,0] > upper[-1,0]: upper = upper[::-1]
    f_up = interp1d(upper[:,0], upper[:,1], bounds_error=False, fill_value="extrapolate")
    f_lo = interp1d(lower[:,0], lower[:,1], bounds_error=False, fill_value="extrapolate")
    return (f_up(x_loc) + f_lo(x_loc)) / 2.0

def generate_geometry(chord, alpha, delta_j, resolution_factor=1.0, nozzle_x_pct=-18.764):
    """
    resolution_factor: Multiplier for panel density. 1.0 = Default.
    """
    hinge_x = 122.5
    nozzle_x = (nozzle_x_pct / 100.0) * chord
    jet_end_x = 2.5 * chord 
    
    z_jet_top = 109.6705
    z_jet_bot = 23.6705
# Default line
    
    raw = load_s1223_coords() * chord
    hinge_y = get_camber_line_y_at_x(hinge_x, raw)
    hinge_pt = np.array([hinge_x, hinge_y])
    
    # 1. Process Airfoil
    airfoil_pts = []
    for p in raw:
        if p[0] > hinge_x:
            p_rot = rotate_points(np.array([p]), delta_j, center=hinge_pt)[0]
            airfoil_pts.append(p_rot)
        else:
            airfoil_pts.append(p)
    airfoil_pts = np.array(airfoil_pts)
    
    # 2. Determine Panel Counts based on Resolution
    n_up = int(40 * resolution_factor)
    n_down = int(50 * resolution_factor)
    
    # 3. Generate Jet Points
    x_up = np.linspace(nozzle_x, hinge_x, n_up)
    len_down = jet_end_x - hinge_x
    x_local_down = np.linspace(0, len_down, n_down)
    
    # -- Jet Top --
    top_up = np.column_stack((x_up, np.full_like(x_up, z_jet_top)))
    pivot_top = np.array([hinge_x, z_jet_top])
    top_down_base = np.column_stack((x_local_down + hinge_x, np.full_like(x_local_down, z_jet_top)))
    top_down_rot = rotate_points(top_down_base, delta_j, center=pivot_top)
    jet_top_pts = np.vstack((top_up, top_down_rot[1:]))
    
    # -- Jet Bottom (With CUTOUT for Airfoil) --
    # Strategy: Only generate points BEFORE LE (0) and AFTER TE (175)
    # LE is approx 0.0, TE is approx 175.0 (chord)
    
    # Part A: Nozzle to LE
    x_nozzle_to_le = np.linspace(nozzle_x, 0.0, int(20 * resolution_factor))
    bot_part_a = np.column_stack((x_nozzle_to_le, np.full_like(x_nozzle_to_le, z_jet_bot)))
    
    # Part B: TE to End
    # TE is at x=chord. We need to find where that is relative to our hinge logic.
    # The hinge is at 122.5. TE is 175.
    # The flap (including TE) is rotated.
    # We need the Jet Bottom to emerge from the rotated TE.
    
    # Find the actual TE location after rotation
    te_orig = np.array([chord, 0.0]) # Approx
    # Better: use last point of airfoil coords if sorted, or find max x
    te_rot = rotate_points(np.array([te_orig]), delta_j, center=hinge_pt)[0]
    
    # Vector for jet direction after deflection
    rad_j = np.radians(delta_j)
    jet_dir = np.array([np.cos(rad_j), np.sin(rad_j)])
    
    # Generate points from Rotated TE downwards
    s_vals = np.linspace(0, jet_end_x - chord, int(40 * resolution_factor))
    
    bot_part_b = []
    for s in s_vals:
        bot_part_b.append(te_rot + s * jet_dir)
    bot_part_b = np.array(bot_part_b)
    
    # Combine Jet Bot (Gap between LE and TE is filled by the Wing itself)
    # The solver handles the wing naturally. We just don't want a "ghost" sheet inside it.
    jet_bot_pts = np.vstack((bot_part_a, bot_part_b))
    
    # 4. Global Alpha Rotation
    rot_alpha = -alpha
    return (discretize_geometry(rotate_points(airfoil_pts, rot_alpha)), 
            discretize_geometry(rotate_points(jet_top_pts, rot_alpha)), 
            discretize_geometry(rotate_points(jet_bot_pts, rot_alpha)))

def get_induced_velocity(target, p1, p2, gamma, sigma):
    panel_vec = p2 - p1
    length = np.linalg.norm(panel_vec)
    tangent = panel_vec / length
    normal = np.array([-tangent[1], tangent[0]])
    d_vec = target - p1
    x_local = np.dot(d_vec, tangent)
    y_local = np.dot(d_vec, normal)
    r1_sq = x_local**2 + y_local**2
    r2_sq = (x_local - length)**2 + y_local**2
    theta1 = np.arctan2(y_local, x_local)
    theta2 = np.arctan2(y_local, x_local - length)
    
    if r1_sq < 1e-10 or r2_sq < 1e-10 or (y_local == 0 and 0 < x_local < length):
        return np.array([0.0, 0.5 * sigma])
        
    val_log = 0.5 * np.log(r2_sq / r1_sq)
    val_atan = theta2 - theta1
    
    u_src_loc = (sigma / (2*np.pi)) * val_log
    v_src_loc = (sigma / (2*np.pi)) * val_atan
    u_vtx_loc = (gamma / (2*np.pi)) * val_atan
    v_vtx_loc = -(gamma / (2*np.pi)) * val_log
    
    u_loc = u_src_loc + u_vtx_loc
    v_loc = v_src_loc + v_vtx_loc
    return u_loc * tangent[0] - v_loc * tangent[1], u_loc * tangent[1] + v_loc * tangent[0]

def solve_system_logic(airfoil, jet_top, jet_bot, Vo, Vj, rho_o, rho_j):
    Na, Nj = len(airfoil), len(jet_top)
    Njb = len(jet_bot)
    
    # Unknowns: 
    # Airfoil Vortex (Na)
    # Jet Top Vortex (Nj) + Source (Nj)
    # Jet Bot Vortex (Njb) + Source (Njb)
    N_unknowns = Na + 2*Nj + 2*Njb
    
    # Kutta Condition: Sum of vortex strengths at TE = 0
    N_equations = N_unknowns + 1 
    
    A = np.zeros((N_equations, N_unknowns))
    b = np.zeros(N_equations)
    
    idx_ga = 0               
    idx_gjt = Na             
    idx_sjt = Na + Nj        
    idx_gjb = Na + 2*Nj      
    idx_sjb = Na + 2*Nj + Njb 
    
    if Vj < 1e-5: Vj = 1e-5
    
    mu = Vo / Vj
    K_p = (rho_o * Vo) / (rho_j * Vj)
    V_inf_vec = np.array([Vj, 0])
    
    # --- AIRFOIL BC (Neumann) ---
    for i in range(Na):
        p_i = airfoil[i]
        b[i] = -np.dot(V_inf_vec, p_i['normal'])
        for j in range(Na):
            vel = get_induced_velocity(p_i['center'], airfoil[j]['p1'], airfoil[j]['p2'], 1, 0)
            A[i, idx_ga+j] = np.dot(vel, p_i['normal'])
        for j in range(Nj): # Top Jet
            v_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1, 0)
            v_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0, 1)
            A[i, idx_gjt+j] = np.dot(v_g, p_i['normal'])
            A[i, idx_sjt+j] = np.dot(v_s, p_i['normal'])
        for j in range(Njb): # Bot Jet
            v_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1, 0)
            v_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0, 1)
            A[i, idx_gjb+j] = np.dot(v_g, p_i['normal'])
            A[i, idx_sjb+j] = np.dot(v_s, p_i['normal'])

    # --- JET BCs ---
    # Helper to clean up the loop
    # List of (panels, vortex_idx_start, source_idx_start)
    jet_surfaces = [(jet_top, idx_gjt, idx_sjt), (jet_bot, idx_gjb, idx_sjb)]
    
    row_offset = Na
    for panels, g_idx, s_idx in jet_surfaces:
        N_curr = len(panels)
        for i in range(N_curr):
            p_i = panels[i]
            
            # 1. Normal BC
            row_n = row_offset + i
            A[row_n, s_idx + i] += 1.0 
            factor = (1.0 - mu)
            b[row_n] = -factor * np.dot(V_inf_vec, p_i['normal'])
            
            # Influences
            for j in range(Na):
                vel = get_induced_velocity(p_i['center'], airfoil[j]['p1'], airfoil[j]['p2'], 1, 0)
                A[row_n, idx_ga+j] += factor * np.dot(vel, p_i['normal'])
            for j in range(Nj): # Top
                v_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0, 1)
                A[row_n, idx_gjt+j] += factor * np.dot(v_g, p_i['normal'])
                A[row_n, idx_sjt+j] += factor * np.dot(v_s, p_i['normal'])
            for j in range(Njb): # Bot
                v_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0, 1)
                A[row_n, idx_gjb+j] += factor * np.dot(v_g, p_i['normal'])
                A[row_n, idx_sjb+j] += factor * np.dot(v_s, p_i['normal'])

            # 2. Tangential BC
            row_t = row_offset + N_curr + i
            factor_tan = (1.0 - K_p)
            A[row_t, g_idx + i] += 1.0
            b[row_t] = -factor_tan * np.dot(V_inf_vec, p_i['tangent'])
            
            for j in range(Na):
                vel = get_induced_velocity(p_i['center'], airfoil[j]['p1'], airfoil[j]['p2'], 1, 0)
                A[row_t, idx_ga+j] += factor_tan * np.dot(vel, p_i['tangent'])
            for j in range(Nj): # Top
                v_g = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_top[j]['p1'], jet_top[j]['p2'], 0, 1)
                A[row_t, idx_gjt+j] += factor_tan * np.dot(v_g, p_i['tangent'])
                A[row_t, idx_sjt+j] += factor_tan * np.dot(v_s, p_i['tangent'])
            for j in range(Njb): # Bot
                v_g = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 1, 0)
                v_s = get_induced_velocity(p_i['center'], jet_bot[j]['p1'], jet_bot[j]['p2'], 0, 1)
                A[row_t, idx_gjb+j] += factor_tan * np.dot(v_g, p_i['tangent'])
                A[row_t, idx_sjb+j] += factor_tan * np.dot(v_s, p_i['tangent'])
        
        row_offset += 2 * N_curr

    # --- KUTTA CONDITION (Explicit) ---
    row_kutta = N_equations - 1
    A[row_kutta, idx_ga] = 1.0       # TE Upper
    A[row_kutta, idx_ga + Na - 1] = 1.0 # TE Lower
    b[row_kutta] = 0.0

    # Solve
    x, residuals, rank, s = np.linalg.lstsq(A, b, rcond=None)
    
    gamma_airfoil = x[0:Na]
    gamma_sum = sum(gamma_airfoil[i] * airfoil[i]['length'] for i in range(Na))
    return gamma_sum

# ==========================================
# PART 2: TKINTER GUI
# ==========================================

class USBApp:
    def __init__(self, root):
        self.root = root
        self.root.title("USB Aerodynamics Solver (S1223 Corrected)")
        self.root.geometry("1100x700")

        # --- Variables ---
        self.var_alpha = tk.DoubleVar(value=0.0)
        self.var_delta_j = tk.DoubleVar(value=0.0)
        self.var_v_jet = tk.DoubleVar(value=40.0)
        self.var_v_out = tk.DoubleVar(value=40.0)
        self.var_resolution = tk.DoubleVar(value=1.0)
        
        # --- Layout Frames ---
        control_frame = ttk.Frame(root, padding="10")
        control_frame.pack(side=tk.LEFT, fill=tk.Y)
        
        plot_frame = ttk.Frame(root, padding="10")
        plot_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)

        # --- Controls ---
        ttk.Label(control_frame, text="Simulation Inputs", font=("Arial", 14, "bold")).pack(pady=10)
        
        self.create_input(control_frame, "Angle of Attack (deg):", self.var_alpha)
        self.create_input(control_frame, "Flap/Jet Deflection (deg):", self.var_delta_j)
        self.create_input(control_frame, "Jet Velocity (V_jet):", self.var_v_jet)
        self.create_input(control_frame, "Freestream Velocity (V_out):", self.var_v_out)
        
        # Slider for panels
        ttk.Label(control_frame, text="Panel Density (Resolution):").pack(anchor=tk.W, pady=(10,0))
        scale = tk.Scale(control_frame, from_=0.5, to=3.0, resolution=0.1, orient=tk.HORIZONTAL, variable=self.var_resolution)
        scale.pack(fill=tk.X)
        
        ttk.Button(control_frame, text="Run Simulation", command=self.run_simulation).pack(pady=20, fill=tk.X)
        
        # Results Display
        self.result_text = tk.StringVar(value="Click Run to see results.")
        lbl_results = ttk.Label(control_frame, textvariable=self.result_text, justify=tk.LEFT, font=("Consolas", 10))
        lbl_results.pack(pady=10, fill=tk.X)

        # --- Matplotlib Canvas ---
        self.figure = Figure(figsize=(6, 5), dpi=100)
        self.ax = self.figure.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.figure, master=plot_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
        # Initial Plot
        self.run_simulation()

    def create_input(self, parent, label_text, variable):
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.X, pady=5)
        ttk.Label(frame, text=label_text).pack(anchor=tk.W)
        ttk.Entry(frame, textvariable=variable).pack(fill=tk.X)

    def run_simulation(self):
        try:
            alpha = self.var_alpha.get()
            delta_j = self.var_delta_j.get()
            V_jet = self.var_v_jet.get()
            V_out = self.var_v_out.get()
            res = self.var_resolution.get()
        except tk.TclError:
            self.result_text.set("Error: Invalid Input")
            return

        chord = 175.0
        rho = 1.225
        t_j = 0.101 
        
        # Generate geometry with CUTOUT logic inside
        airfoil, jet_top, jet_bot = generate_geometry(chord, alpha, delta_j, resolution_factor=res)
        
        if V_jet <= 0.1: V_jet = 0.1 
        gamma_sum = solve_system_logic(airfoil, jet_top, jet_bot, V_out, V_jet, rho, rho)
        
        Cl_circ = 2.0 * gamma_sum / (V_jet * chord)
        m_dot = rho * t_j * V_jet
        theta_total = np.radians(alpha + abs(delta_j))
        Lift_jet = m_dot * V_jet * np.sin(theta_total)
        
        if V_out < 1.0: q_inf = 0.5 * rho * (1.0)**2 
        else: q_inf = 0.5 * rho * V_out**2
            
        S_ref = chord * 1.0
        Cl_jet = Lift_jet / (q_inf * S_ref)
        Cl_total = Cl_circ + Cl_jet

        res_str = (f"=== RESULTS ===\n"
                   f"V_jet / V_out Ratio: {V_jet/V_out:.2f}\n"
                   f"Circulation Cl: {Cl_circ:.4f}\n"
                   f"Jet Reaction Cl: {Cl_jet:.4f}\n"
                   f"TOTAL Cl:       {Cl_total:.4f}")
        
        if abs(V_jet - V_out) < 0.1:
            res_str += "\n\n[NOTE: V_jet approx equal to V_out.]"
            
        self.result_text.set(res_str)

        self.ax.clear()
        
        p_af = np.array([p['p1'] for p in airfoil] + [airfoil[-1]['p2']])
        p_jt = np.array([p['p1'] for p in jet_top] + [jet_top[-1]['p2']])
        p_jb = np.array([p['p1'] for p in jet_bot] + [jet_bot[-1]['p2']])
        
        self.ax.plot(p_af[:,0], p_af[:,1], 'k-', linewidth=2, label='Airfoil S1223')
        self.ax.plot(p_jt[:,0], p_jt[:,1], 'r--', label='Jet Top')
        self.ax.plot(p_jb[:,0], p_jb[:,1], 'b--', label='Jet Bottom')
        
        h_x = 122.5 * np.cos(np.radians(-alpha))
        h_y = 122.5 * np.sin(np.radians(-alpha))
        self.ax.axvline(x=h_x, color='g', linestyle=':', alpha=0.5, label='Hinge')
        
        self.ax.set_title(f"USB Flow | Res={res} | Cl={Cl_total:.3f}")
        self.ax.set_xlabel("x (mm)")
        self.ax.set_ylabel("z (mm)")
        self.ax.axis('equal')
        self.ax.grid(True)
        self.ax.legend()
        self.canvas.draw()

if __name__ == "__main__":
    root = tk.Tk()
    app = USBApp(root)
    root.mainloop()