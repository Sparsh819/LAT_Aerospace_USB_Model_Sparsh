import numpy as np
import matplotlib.pyplot as plt
import argparse

def generate_s1223_camber(x, naca=None):
    """
    Approximates the S1223 mean camber line.
    S1223 has a very high camber (~8-9%) peaking near 40-50% chord.
    """
    # Handle both scalar and array inputs
    x = np.atleast_1d(x)
    z = 0.36 * x * (1 - x) * (1 + 0.5 * x)
    return z if len(z) > 1 else z[0]

def rotate_point(origin, point, angle_deg):
    """
    Rotates a point counterclockwise by a given angle around a given origin.
    """
    angle_rad = np.radians(angle_deg)
    ox, oy = origin
    px, py = point
    
    qx = ox + np.cos(angle_rad) * (px - ox) - np.sin(angle_rad) * (py - oy)
    qy = oy + np.sin(angle_rad) * (px - ox) + np.cos(angle_rad) * (py - oy)
    return qx, qy

def get_2d_induced_velocity(target, vortex_loc, gamma=1.0, Mach=0.0):
    """
    Computes induced velocity at target point due to a 2D point vortex.
    Uses compressibility correction factor beta = sqrt(1 - M^2).
    """
    beta = np.sqrt(1.0 - Mach**2) if Mach < 1.0 else 0.1
    
    dx = target[0] - vortex_loc[0]
    dz = target[1] - vortex_loc[1]
    
    r_sq = dx**2 + (beta * dz)**2
    
    if r_sq < 1e-10:
        return np.array([0.0, 0.0])
    
    # Vortex strength produces tangential velocity
    u = -gamma * beta * dz / (2.0 * np.pi * r_sq)
    w = gamma * dx / (2.0 * np.pi * r_sq)
    
    return np.array([u, w])

def discretize_curve(x_points, z_points):
    """
    Discretizes a generic curve defined by points into vortex panels.
    """
    num_panels = len(x_points) - 1
    
    vortices = []
    control_points = []
    normals = []
    tangents = []
    
    for k in range(num_panels):
        p1 = np.array([x_points[k], z_points[k]])
        p2 = np.array([x_points[k+1], z_points[k+1]])
        
        panel_vec = p2 - p1
        length = np.linalg.norm(panel_vec)
        unit_tan = panel_vec / length
        
        # Normal (90 deg counter-clockwise from tangent)
        unit_norm = np.array([-unit_tan[1], unit_tan[0]])
        
        # Vortex at 1/4 chord, Control Point at 3/4 chord
        vortex_loc = p1 + 0.25 * panel_vec
        cp_loc = p1 + 0.75 * panel_vec
        
        vortices.append(vortex_loc)
        control_points.append(cp_loc)
        normals.append(unit_norm)
        tangents.append(unit_tan)
    
    return {
        'vortices': np.array(vortices),
        'control_points': np.array(control_points),
        'normals': np.array(normals),
        'tangents': np.array(tangents)
    }

def generate_wing_geometry(x_start, x_end, num_panels, camber_func, naca=None):
    """
    Generate wing geometry using the camber function.
    """
    x_vals = np.linspace(x_start, x_end, num_panels + 1)
    z_vals = camber_func(x_vals, naca)
    return discretize_curve(x_vals, z_vals)

def generate_jet_geometry_with_flap(chord_mm, jet_thickness_mm, delta_j, 
                                     hinge_x_pct, num_panels, downstream_len_mm):
    """
    Generates jet geometry with rectangular cross-section and flap deflection.
    The bottom surface starts at z=0 (touching bottom of camber).
    Both surfaces bend at 70% chord.
    """
    # Convert to normalized chord units
    chord = chord_mm / chord_mm  # = 1.0
    t_c = jet_thickness_mm / chord_mm
    x_hinge = hinge_x_pct
    x_jet_end = (hinge_x_pct * chord_mm + downstream_len_mm) / chord_mm
    
    # --- Lower Surface (starts at z=0) ---
    # Part A: Horizontal (Leading Edge to Hinge)
    x_lower_flat = np.linspace(0, x_hinge, num_panels // 2 + 1)
    z_lower_flat = np.zeros_like(x_lower_flat)
    
    # Part B: Angled (Hinge to End)
    hinge_pt_lower = (x_hinge, 0.0)
    
    x_lower_angled_raw = np.linspace(x_hinge, x_jet_end, num_panels // 2 + 1)
    z_lower_angled_raw = np.zeros_like(x_lower_angled_raw)
    
    x_lower_bent = []
    z_lower_bent = []
    
    for i in range(len(x_lower_angled_raw)):
        px, py = x_lower_angled_raw[i], z_lower_angled_raw[i]
        rx, ry = rotate_point(hinge_pt_lower, (px, py), delta_j)
        x_lower_bent.append(rx)
        z_lower_bent.append(ry)
    
    # Combine (remove duplicate hinge point)
    x_jet_lower = np.concatenate([x_lower_flat[:-1], x_lower_bent])
    z_jet_lower = np.concatenate([z_lower_flat[:-1], z_lower_bent])
    
    # --- Upper Surface (offset by thickness) ---
    # Part A: Horizontal
    x_upper_flat = np.linspace(0, x_hinge, num_panels // 2 + 1)
    z_upper_flat = np.full_like(x_upper_flat, t_c)
    
    # Part B: Angled (rotate around same hinge point to maintain block shape)
    x_upper_angled_raw = np.linspace(x_hinge, x_jet_end, num_panels // 2 + 1)
    z_upper_angled_raw = np.full_like(x_upper_angled_raw, t_c)
    
    x_upper_bent = []
    z_upper_bent = []
    
    for i in range(len(x_upper_angled_raw)):
        px, py = x_upper_angled_raw[i], z_upper_angled_raw[i]
        rx, ry = rotate_point(hinge_pt_lower, (px, py), delta_j)
        x_upper_bent.append(rx)
        z_upper_bent.append(ry)
    
    # Combine (remove duplicate hinge point)
    x_jet_upper = np.concatenate([x_upper_flat[:-1], x_upper_bent])
    z_jet_upper = np.concatenate([z_upper_flat[:-1], z_upper_bent])
    
    # Use lower surface for vortex model
    return discretize_curve(x_jet_lower, z_jet_lower), (x_jet_upper, z_jet_upper)

def compute_usb_matrices(wing_geometry, jet_geometry, Mach_o=0.0, Mach_j=0.0):
    """
    Computes the Aerodynamic Influence Coefficient matrices for a USB configuration.
    """
    w_vort = wing_geometry['vortices']
    w_cp = wing_geometry['control_points']
    w_norm = wing_geometry['normals']
    
    j_vort = jet_geometry['vortices']
    j_cp = jet_geometry['control_points']
    j_norm = jet_geometry['normals']
    j_tan = jet_geometry['tangents']
    
    Nw = len(w_vort)
    Nj = len(j_vort)
    
    # Initialize Matrices
    N_WW = np.zeros((Nw, Nw))
    N_WJ = np.zeros((Nw, Nj))
    
    N_JW_o = np.zeros((Nj, Nw))
    S_JW_o = np.zeros((Nj, Nw))
    N_JJ_o = np.zeros((Nj, Nj))
    S_JJ_o = np.zeros((Nj, Nj))
    
    N_JW_j = np.zeros((Nj, Nw))
    S_JW_j = np.zeros((Nj, Nw))
    N_JJ_j = np.zeros((Nj, Nj))
    S_JJ_j = np.zeros((Nj, Nj))
    
    # Compute Wing Control Point Influences
    for i in range(Nw):
        target = w_cp[i]
        n_vec = w_norm[i]
        
        for k in range(Nw):
            vel = get_2d_induced_velocity(target, w_vort[k], gamma=1.0, Mach=Mach_o)
            N_WW[i, k] = np.dot(vel, n_vec)
        
        for k in range(Nj):
            vel = get_2d_induced_velocity(target, j_vort[k], gamma=1.0, Mach=Mach_o)
            N_WJ[i, k] = np.dot(vel, n_vec)
    
    # Compute Jet Control Point Influences
    for i in range(Nj):
        target = j_cp[i]
        n_vec = j_norm[i]
        t_vec = j_tan[i]
        
        # Outer Flow (Mach_o)
        for k in range(Nw):
            vel = get_2d_induced_velocity(target, w_vort[k], gamma=1.0, Mach=Mach_o)
            N_JW_o[i, k] = np.dot(vel, n_vec)
            S_JW_o[i, k] = np.dot(vel, t_vec)
        
        for k in range(Nj):
            vel = get_2d_induced_velocity(target, j_vort[k], gamma=1.0, Mach=Mach_o)
            N_JJ_o[i, k] = np.dot(vel, n_vec)
            S_JJ_o[i, k] = np.dot(vel, t_vec)
        
        # Jet Flow (Mach_j)
        for k in range(Nw):
            vel = get_2d_induced_velocity(target, w_vort[k], gamma=1.0, Mach=Mach_j)
            N_JW_j[i, k] = np.dot(vel, n_vec)
            S_JW_j[i, k] = np.dot(vel, t_vec)
        
        for k in range(Nj):
            vel = get_2d_induced_velocity(target, j_vort[k], gamma=1.0, Mach=Mach_j)
            N_JJ_j[i, k] = np.dot(vel, n_vec)
            S_JJ_j[i, k] = np.dot(vel, t_vec)
    
    return {
        "N_WW": N_WW, "N_WJ": N_WJ,
        "N_JW_o": N_JW_o, "S_JW_o": S_JW_o,
        "N_JJ_o": N_JJ_o, "S_JJ_o": S_JJ_o,
        "N_JW_j": N_JW_j, "S_JW_j": S_JW_j,
        "N_JJ_j": N_JJ_j, "S_JJ_j": S_JJ_j
    }

def solve_usb_system(mats, wing_geom, jet_geom, flow_params):
    """
    Solves for [gamma_wa, gamma_oj, gamma_jj] using corrected physics.
    """
    Vo = flow_params['V_o']
    Vj = flow_params['V_j']
    rho_o = flow_params['rho_o']
    rho_j = flow_params['rho_j']
    alpha_rad = np.radians(flow_params['alpha'])
    
    V_ent = flow_params.get('V_ent', np.array([0.0, 0.0]))
    
    Nw = mats['N_WW'].shape[0]
    Nj = mats['N_JJ_o'].shape[0]
    
    # Ratios
    mu = Vo / Vj
    mu_dash = mu  # Assuming small perturbations approximation
    
    # CORRECTION: Using T*mu (momentum ratio) instead of T*mu^2 (dynamic pressure ratio)
    # for linearized pressure continuity (Eq 4)
    T = rho_o / rho_j
    factor_eq4 = T * mu 
    
    V_inf_vec = Vo * np.array([np.cos(alpha_rad), np.sin(alpha_rad)])
    
    # Solve Wing-Alone
    RHS_wo = np.zeros(Nw)
    for i in range(Nw):
        RHS_wo[i] = -np.dot(V_inf_vec, wing_geom['normals'][i])
    gamma_wo = np.linalg.solve(mats['N_WW'], RHS_wo)
    
    # Build RHS for Equation 3 (Linearized Flow Tangency)
    RHS1 = np.zeros(Nj)
    dphi_wo_dn = mats['N_JW_o'] @ gamma_wo
    
    for i in range(Nj):
        n_i = jet_geom['normals'][i]
        Vo_dot_n = np.dot(V_inf_vec, n_i)
        
        # Eq 3: (Vo.n)(1 - mu') + (dphi_o/dn) - mu'(dphi_j/dn) = 0
        # Rearranged for unknown gammas on LHS:
        # dphi_oj/dn - mu' * dphi_jj/dn = -(Vo.n)(1-mu') - dphi_wo/dn
        geom_term = Vo_dot_n * (1.0 - mu_dash) 
        RHS1[i] = -geom_term - dphi_wo_dn[i]

    # Build RHS for Equation 4 (Linearized Pressure Continuity)
    RHS2 = np.zeros(Nj)
    dphi_wo_ds = mats['S_JW_o'] @ gamma_wo
    
    for i in range(Nj):
        # Eq 4: rho_j*Vj*u_j = rho_o*Vo*u_o
        # u_j = (T*mu) * u_o
        # u_jj - (T*mu)*u_oj = (T*mu)*u_wo
        # Using negative form for matrix consistency:
        # (T*mu)*u_oj - u_jj = -(T*mu)*u_wo
        RHS2[i] = -factor_eq4 * dphi_wo_ds[i]
    
    Vje_k = V_ent[1]
    RHS3 = np.full(Nw, -Vje_k / (Vo * np.cos(alpha_rad)))
    
    # Assemble system
    n_unknowns = Nw + 2 * Nj
    n_eqs = 2 * Nj + Nw
    
    A = np.zeros((n_eqs, n_unknowns))
    b = np.zeros(n_eqs)
    
    # Equation 3 (Linearized Flow Tangency)
    A[0:Nj, 0:Nw] = mats['N_JW_o']
    A[0:Nj, Nw:Nw+Nj] = mats['N_JJ_o']
    # CORRECTION: Added mu_dash multiplier to jet influence
    A[0:Nj, Nw+Nj:Nw+2*Nj] = -mu_dash * mats['N_JJ_j'] 
    b[0:Nj] = RHS1
    
    # Equation 4 (Linearized Pressure Continuity)
    # factor * u_oj - u_jj = ...
    A[Nj:2*Nj, 0:Nw] = -factor_eq4 * mats['S_JW_o']
    A[Nj:2*Nj, Nw:Nw+Nj] = -factor_eq4 * mats['S_JJ_o']
    A[Nj:2*Nj, Nw+Nj:Nw+2*Nj] = mats['S_JJ_j']
    b[Nj:2*Nj] = RHS2
    
    # Equation 5 (Wing Surface Flow Tangency)
    A[2*Nj:2*Nj+Nw, 0:Nw] = mats['N_WW']
    A[2*Nj:2*Nj+Nw, Nw:Nw+Nj] = mats['N_WJ']
    b[2*Nj:2*Nj+Nw] = RHS3
    
    # Solve
    sol = np.linalg.solve(A, b)
    
    gamma_wa = sol[0:Nw]
    gamma_oj = sol[Nw:Nw+Nj]
    gamma_jj = sol[Nw+Nj:Nw+2*Nj]
    
    return {
        "gamma_wo": gamma_wo,
        "gamma_wa": gamma_wa,
        "gamma_oj": gamma_oj,
        "gamma_jj": gamma_jj
    }

def compute_lift_coefficient(gamma_w, wing_geom, alpha, chord, V_ref, verbose=False):
    """
    Computes sectional lift coefficient.
    CORRECTION: Includes division by V_ref to ensure non-dimensional CL.
    """
    alpha_rad = np.radians(alpha)
    x_vorts = wing_geom['vortices'][:, 0]
    tangents = wing_geom['tangents']
    
    if verbose:
        print(f"\n--- CL Calculation (V_ref={V_ref:.2f}) ---")
    
    cl_val = 0.0
    for i in range(len(gamma_w) - 1):
        dx = x_vorts[i+1] - x_vorts[i]
        gamma_avg = 0.5 * (gamma_w[i] + gamma_w[i+1])
        
        # Local panel angle
        tan_avg = 0.5 * (tangents[i] + tangents[i+1])
        theta_local = np.arctan2(tan_avg[1], tan_avg[0])
        
        cl_val += gamma_avg * dx * np.cos(alpha_rad - theta_local)
        
    # Non-dimensionalize: CL = L / (0.5 * rho * V^2 * c)
    # L = rho * V * Gamma_total
    # CL = 2 * Gamma_total / (V * c)
    cl_val = 2.0 * cl_val / (chord * V_ref)
    
    return cl_val

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--V_o', type=float, default=20.0)
    p.add_argument('--V_j', type=float, default=63.7) 
    p.add_argument('--rho_o', type=float, default=1.225)
    p.add_argument('--rho_j', type=float, default=1.225)
    p.add_argument('--alpha', type=float, default=5.0)
    p.add_argument('--cmu', type=float, default=3.297)
    p.add_argument('--delta_j', type=float, default=-20.0)
    p.add_argument('--num_panels_w', type=int, default=300)
    p.add_argument('--num_panels_j', type=int, default=300)
    p.add_argument('--jet_thickness_mm', type=float, default=86.0)
    p.add_argument('--chord_mm', type=float, default=175.0)
    p.add_argument('--downstream_len_mm', type=float, default=400.0)
    args = p.parse_args()
    
    # Compute Mach numbers
    Mach_o = args.V_o / 343.0
    Mach_j = args.V_j / 343.0
    
    print(f"=== USB Analysis: S1223 Airfoil ===")
    print(f"V_o = {args.V_o} m/s, V_j = {args.V_j} m/s")
    print(f"Alpha = {args.alpha}°")
    
    # Generate geometries
    wing_geom = generate_wing_geometry(0.0, 1.0, args.num_panels_w, 
                                       generate_s1223_camber, naca=None)
    
    jet_geom, jet_upper = generate_jet_geometry_with_flap(
        args.chord_mm, args.jet_thickness_mm, args.delta_j, 
        0.7, args.num_panels_j, args.downstream_len_mm)
    
    # Compute influence matrices
    print("\nComputing influence matrices...")
    mats = compute_usb_matrices(wing_geom, jet_geom, Mach_o, Mach_j)
    
    # Solve system
    print("Solving vortex system...")
    flow_params = {
        'V_o': args.V_o,
        'V_j': args.V_j,
        'rho_o': args.rho_o,
        'rho_j': args.rho_j,
        'alpha': args.alpha,
        'V_ent': np.array([0.0, 0.0])
    }
    
    sol = solve_usb_system(mats, wing_geom, jet_geom, flow_params)
    
    # Calculate Final CL
    gamma_total = sol['gamma_wo'] + sol['gamma_wa']
    cl_total = compute_lift_coefficient(gamma_total, wing_geom, args.alpha, 1.0, args.V_o, verbose=True)
    
    print(f"\n=== RESULTS ===")
    print(f"Lift Coefficient (C_L): {cl_total:.4f}")
    
    # Visualization
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 8))
    
    # Plot 1: Geometry
    x_camber = np.linspace(0, 1.0, 200)
    z_camber = generate_s1223_camber(x_camber, None)
    
    ax1.plot(x_camber, z_camber, 'k-', linewidth=2, label='S1223 Camber')
    ax1.plot(jet_geom['vortices'][:, 0], jet_geom['vortices'][:, 1], 
             'r-', linewidth=2, label='Jet Bottom')
    ax1.plot(jet_upper[0], jet_upper[1], 'b-', linewidth=2, label='Jet Top')
    
    ax1.set_xlabel('x/c')
    ax1.set_ylabel('z/c')
    ax1.set_title(f'S1223 + Jet (δ_j={args.delta_j}°)')
    ax1.axis('equal')
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    
    # Plot 2: Gamma
    ax2.plot(wing_geom['vortices'][:, 0], gamma_total, 'b-', label='Total Gamma')
    ax2.set_xlabel('x/c')
    ax2.set_ylabel('Gamma')
    ax2.set_title('Vortex Distribution')
    ax2.grid(True)
    ax2.legend()
    
    plt.tight_layout()
    plt.show()

if __name__ == '__main__':
    main()